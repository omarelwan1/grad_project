import json, os, glob

for p in sorted(glob.glob("auto_outputs/test_heightmap2/*/metrics.json")):
    m = json.load(open(p))
    name = os.path.dirname(p).split(os.sep)[-1]
    iou  = m["silhouette_iou"]
    tris = m["triangles"]
    rt   = m["runtime_seconds"]
    emp  = m["empty_mesh"]
    print(name + ": IoU=" + str(round(iou,3)) + "  tris=" + str(tris) + "  t=" + str(round(rt,1)) + "s  empty=" + str(emp))
