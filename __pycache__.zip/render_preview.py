
"""
render_preview.py — Thread-safe 3D mesh rendering.

Uses FigureCanvasAgg directly without touching the global matplotlib backend,
so it coexists peacefully with viewer_window.py which uses FigureCanvasTkAgg.
"""

import io
import numpy as np
from PIL import Image

from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg


def mesh_to_pil(mesh, elev: float = 28, azim: float = -55, dpi: int = 150) -> Image.Image:
    """
    Render a trimesh/SimpleMesh as a PIL image.

    Thread-safe: uses FigureCanvasAgg (non-interactive, no Tk) so it can be
    called from any background worker thread without crashing the main Tk loop.

    Camera:
      elev=28   — slightly above the anatomy for clear depth perception
      azim=-55  — frontal-oblique matching conventional US viewing angle

    Colour: magma colormap mapped to vertex Z depth (deep=dark, peak=bright)
    on a dark navy background for clinical contrast.
    """
    v = np.asarray(mesh.vertices, dtype=np.float32)
    f = np.asarray(mesh.faces,    dtype=np.int32)

    fig = Figure(figsize=(5, 4), dpi=dpi, facecolor="#10102a")
    FigureCanvasAgg(fig)   # attach a non-interactive Agg canvas (thread-safe)
    ax = fig.add_subplot(111, projection="3d", facecolor="#10102a")
    ax.set_axis_off()
    ax.view_init(elev=float(elev), azim=float(azim))

    if f.size > 0 and v.size > 0:
        # Normalise vertex coordinates to [0,1] so the mesh fills the frame
        vn = v.copy()
        for i in range(3):
            lo, hi = vn[:, i].min(), vn[:, i].max()
            if hi - lo > 1e-6:
                vn[:, i] = (vn[:, i] - lo) / (hi - lo)

        # Per-face Z mean → colour array (magma: low Z = dark, high Z = bright)
        z_face = (vn[f[:, 0], 2] + vn[f[:, 1], 2] + vn[f[:, 2], 2]) / 3.0
        zmin, zmax = float(z_face.min()), float(z_face.max())
        z_norm = (z_face - zmin) / (zmax - zmin + 1e-9)

        ax.plot_trisurf(
            vn[:, 0], vn[:, 1], vn[:, 2],
            triangles=f,
            cmap="magma",
            array=z_norm,
            linewidth=0.0,
            antialiased=True,
            shade=True,
            alpha=0.95,
        )
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_zlim(0, 1)
        ax.set_box_aspect((1, 1, 0.5))   # flatten Z so terrain reads naturally
    else:
        ax.text2D(0.5, 0.5, "EMPTY MESH",
                  transform=ax.transAxes, ha="center", va="center",
                  color="white", fontsize=14)

    fig.tight_layout(pad=0)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight",
                facecolor=fig.get_facecolor())
    buf.seek(0)
    return Image.open(buf).convert("RGBA")
