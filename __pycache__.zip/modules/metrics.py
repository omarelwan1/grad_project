
import numpy as np
from scipy.ndimage import binary_fill_holes, binary_dilation


def _rasterize_mesh_silhouette(mesh, shape_hw):
    """
    Build a filled top-down silhouette of the mesh projected onto the XY plane.

    IMPORTANT: marching_cubes already returns vertices in voxel coordinates
    that directly correspond to the volume array indices (Y, X). So we map
    them to pixel positions WITHOUT any scaling or normalization — just direct
    integer rounding and clamping. Normalizing was the root bug that stretched
    a small anatomy region to fill the whole image, killing the IoU.

    Steps:
      1. Map vertex X/Y coords directly to image pixel positions.
      2. Mark both vertices and face midpoints so large decimated triangles
         don't leave empty gaps in the projection.
      3. Dilate slightly to close sub-pixel gaps between adjacent triangles.
      4. Fill interior holes so a shell mesh projects as a solid silhouette.
    """
    H, W = shape_hw
    sil = np.zeros((H, W), dtype=np.uint8)
    v = mesh.vertices
    f = mesh.faces
    if f.size == 0 or v.size == 0:
        return sil

    # v[:,0] = X (width axis, range 0..W),  v[:,1] = Y (height axis, range 0..H)
    x = v[:, 0].astype(np.float32)
    y = v[:, 1].astype(np.float32)

    # Direct pixel mapping — no normalization
    px = np.clip(np.round(x).astype(int), 0, W - 1)
    py = np.clip(np.round(y).astype(int), 0, H - 1)
    sil[py, px] = 1

    # Mark face midpoints to fill gaps from large decimated triangles
    if f.size > 0:
        for col, arr in [(x, px), (y, py)]:
            pass  # placeholders replaced below
        mid_x = x[f].mean(axis=1)
        mid_y = y[f].mean(axis=1)
        mid_px = np.clip(np.round(mid_x).astype(int), 0, W - 1)
        mid_py = np.clip(np.round(mid_y).astype(int), 0, H - 1)
        sil[mid_py, mid_px] = 1

    # Close sub-pixel gaps with a small dilation then fill interior holes
    sil = binary_dilation(sil, iterations=2).astype(np.uint8)
    sil = binary_fill_holes(sil).astype(np.uint8)
    return sil


def silhouette_iou(mesh, mask01: np.ndarray) -> float:
    mask = (mask01 > 0).astype(np.uint8)
    sil  = _rasterize_mesh_silhouette(mesh, mask.shape)
    inter = np.logical_and(mask, sil).sum()
    union = np.logical_or(mask, sil).sum()
    return float(inter / (union + 1e-9))


def mesh_quality_stats(mesh) -> dict:
    v = mesh.vertices
    f = mesh.faces
    if f.size == 0 or v.size == 0:
        return {"empty": True}
    tri = v[f]
    e01 = np.linalg.norm(tri[:, 0] - tri[:, 1], axis=1)
    e12 = np.linalg.norm(tri[:, 1] - tri[:, 2], axis=1)
    e20 = np.linalg.norm(tri[:, 2] - tri[:, 0], axis=1)
    edges = np.stack([e01, e12, e20], axis=1)
    a, b, c = edges[:, 0], edges[:, 1], edges[:, 2]
    s = 0.5 * (a + b + c)
    area = np.sqrt(np.clip(s * (s - a) * (s - b) * (s - c), 0.0, None))
    peri = edges.sum(axis=1) + 1e-9
    shape_q = (4.0 * np.sqrt(3.0) * area) / (peri ** 2)
    return {
        "triangle_area_mean": float(area.mean()),
        "triangle_area_std":  float(area.std()),
        "edge_len_mean":      float(edges.mean()),
        "edge_len_std":       float(edges.std()),
        "shape_quality_mean": float(shape_q.mean()),
        "shape_quality_min":  float(shape_q.min()),
        "shape_quality_max":  float(shape_q.max()),
    }
