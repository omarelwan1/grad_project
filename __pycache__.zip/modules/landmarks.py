
import numpy as np
from scipy.ndimage import gaussian_filter, distance_transform_edt
from skimage.measure import find_contours
from modules.logger import log


def _find_true_head_center(mask: np.ndarray):
    """
    Finds head center by restricting DT to upper 40% of mask's Y extent.
    Returns (x_c, y_c, head_radius) or None.
    """
    H, W = mask.shape
    occupied_rows = np.where(mask.any(axis=1))[0]
    if occupied_rows.size == 0:
        return None

    y_top = int(occupied_rows.min())
    y_bottom = int(occupied_rows.max())

    for frac in (0.40, 0.50, 0.65, 0.80):
        y_limit = y_top + int(frac * (y_bottom - y_top))
        head_region = mask.copy()
        head_region[y_limit:, :] = False
        if not head_region.any():
            continue
        dt = distance_transform_edt(head_region)
        if dt.max() < 1e-3:
            continue
        yh, xh = np.unravel_index(np.argmax(dt), dt.shape)
        r = float(dt[yh, xh])
        if r > 10:
            log(f"Head center search window: upper {frac*100:.0f}%")
            return float(xh), float(yh), r
    return None


def _face_angle_from_brightness(img_pre: np.ndarray, x_c: float, y_c: float,
                                  head_radius: float) -> float:
    """
    Determines the facial side by sampling IMAGE BRIGHTNESS in a ring around the
    head center at r ≈ 0.90-1.20 * head_radius.

    Bone tissue reflects ultrasound strongly → bright pixels.
    The facial arc (skull rim, nasal bone, mandible) is BRIGHTEST on the face side.

    Sweeps 360° in 6° bins and finds the peak-brightness sector.
    Returns the face angle in degrees.
    """
    H, W = img_pre.shape[:2]
    BIN_DEG = 6
    n_bins = 360 // BIN_DEG
    bin_brightness = np.zeros(n_bins)
    bin_counts = np.zeros(n_bins)

    # Sample at multiple radii to catch the bone arc
    for frac in np.linspace(0.90, 1.20, 10):
        r = frac * head_radius
        n_angles = max(180, int(2 * np.pi * r))
        for i in range(n_angles):
            ang_rad = 2 * np.pi * i / n_angles
            px = x_c + r * np.cos(ang_rad)
            py = y_c + r * np.sin(ang_rad)
            ix = int(np.clip(round(px), 0, W - 1))
            iy = int(np.clip(round(py), 0, H - 1))
            brightness = float(img_pre[iy, ix])
            ang_deg = np.degrees(ang_rad)
            if ang_deg > 180:
                ang_deg -= 360
            b = int((ang_deg + 180) / BIN_DEG) % n_bins
            bin_brightness[b] += brightness
            bin_counts[b] += 1

    bin_counts = np.maximum(bin_counts, 1)
    bin_means = bin_brightness / bin_counts

    # Circularly smooth (5-bin window each side)
    smoothed = np.array([
        np.mean([bin_means[(i + j) % n_bins] for j in range(-5, 6)])
        for i in range(n_bins)
    ])

    peak_bin = int(np.argmax(smoothed))
    face_angle_deg = float((peak_bin * BIN_DEG) - 180)
    log(f"Face angle from brightness sampling: {face_angle_deg:.1f}° (bin {peak_bin})")
    return face_angle_deg


def detect_landmarks(mask: np.ndarray, height_map_z: np.ndarray,
                     img_pre: np.ndarray = None) -> dict:
    """
    Detects fetal facial landmarks using Brightness-Guided Face-Side Detection:

    1.  Find Head Center via DT restricted to upper 40% of mask.
    2.  Find Face Direction by sampling bone brightness in a ring around the head
        in the preprocessed image (bone/skull = bright in ultrasound).
    3.  Collect facial arc candidates (±55°) from the original mask contour.
    4.  Sort by Y and assign Forehead / Nose Tip / Chin from peaks.

    Returns dict: landmark_name -> (x, y, z).
    """
    landmarks = {}
    H, W = mask.shape

    # ------------------------------------------------------------------ #
    #  Depth map                                                           #
    # ------------------------------------------------------------------ #
    if len(height_map_z.shape) == 3:
        h_map = np.zeros((H, W), dtype=np.float32)
        for y in range(H):
            for x in range(W):
                slices = np.where(height_map_z[:, y, x] > 0.25)[0]
                if slices.size > 0:
                    h_map[y, x] = float(slices.max())
    else:
        h_map = height_map_z.astype(np.float32)

    # ------------------------------------------------------------------ #
    #  Step 1: Head Center                                                 #
    # ------------------------------------------------------------------ #
    result = _find_true_head_center(mask)
    if result is None:
        log("Head center detection failed.")
        return landmarks
    x_c, y_c, head_radius = result
    z_c = float(h_map[int(np.clip(y_c, 0, H-1)), int(np.clip(x_c, 0, W-1))])
    landmarks["Head Center"] = (x_c, y_c, z_c)
    log(f"Head Center: ({x_c:.1f}, {y_c:.1f}), radius={head_radius:.1f}")

    # ------------------------------------------------------------------ #
    #  Step 2: Face Direction via brightness sampling OR body-opposite     #
    # ------------------------------------------------------------------ #
    if img_pre is not None:
        face_angle_deg = _face_angle_from_brightness(img_pre, x_c, y_c, head_radius)
    else:
        # Fallback: body centroid opposite
        ys_all, xs_all = np.where(mask)
        dists = np.sqrt((xs_all - x_c)**2 + (ys_all - y_c)**2)
        body_mask = dists > 1.5 * head_radius
        if body_mask.sum() > 80:
            bx = float(np.mean(xs_all[body_mask]))
            by = float(np.mean(ys_all[body_mask]))
            face_angle_deg = float(np.degrees(np.arctan2(-(by - y_c), -(bx - x_c))))
        else:
            face_angle_deg = 0.0
        log(f"Face angle (body-opposite fallback): {face_angle_deg:.1f}°")

    # ------------------------------------------------------------------ #
    #  Step 3: Original mask contour + head annular filter                 #
    # ------------------------------------------------------------------ #
    try:
        contours = find_contours(mask, 0.5)
        if not contours:
            log("No contours found.")
            return landmarks
        main_contour = max(contours, key=len)

        r_min = 0.78 * head_radius
        r_max = 1.50 * head_radius
        shell_pts = []
        for pt in main_contour:
            py, px = float(pt[0]), float(pt[1])
            if py < 5 or py > H - 6 or px < 5 or px > W - 6:
                continue
            d = np.sqrt((px - x_c)**2 + (py - y_c)**2)
            if r_min < d < r_max:
                ang = np.degrees(np.arctan2(py - y_c, px - x_c))
                shell_pts.append((px, py, ang, d))

        log(f"Head shell points: {len(shell_pts)}")
        if len(shell_pts) < 10:
            return landmarks

        # ------------------------------------------------------------------ #
        #  Step 4: Facial arc ±55° from detected face direction              #
        # ------------------------------------------------------------------ #
        # Wider ±100° arc to capture full Forehead-to-Chin span:
        # In a side-on profile, forehead can be ~80° above face direction,
        # chin ~65° below, totalling ~145° spread.
        arc_half = 100.0
        facial_pts = []
        for px, py, ang, d in shell_pts:
            diff = abs(ang - face_angle_deg)
            if diff > 180:
                diff = 360 - diff
            if diff <= arc_half:
                facial_pts.append((px, py, d))

        log(f"Facial arc candidates: {len(facial_pts)}")

        if len(facial_pts) < 6:
            best = max(shell_pts, key=lambda p: p[3])
            bx, by = best[0], best[1]
            bz = float(h_map[int(np.clip(by, 0, H-1)), int(np.clip(bx, 0, W-1))])
            landmarks["Nose Tip (Est)"] = (bx, by, bz)
            return landmarks

        # ------------------------------------------------------------------ #
        #  Step 5: Sort by Y → Forehead (top) / Nose Tip / Chin (bottom)    #
        # ------------------------------------------------------------------ #
        facial_pts_sorted = sorted(facial_pts, key=lambda p: p[1])
        fx = np.array([p[0] for p in facial_pts_sorted])
        fy = np.array([p[1] for p in facial_pts_sorted])
        fd = np.array([p[2] for p in facial_pts_sorted])

        sigma = max(2.5, len(fd) / 50.0)
        fd_smooth = gaussian_filter(fd, sigma=sigma, mode='nearest')

        threshold = np.mean(fd_smooth) * 0.90
        peaks = []
        for i in range(4, len(fd_smooth) - 4):
            window = fd_smooth[max(0, i - 5):i + 6]
            if fd_smooth[i] == np.max(window) and fd_smooth[i] > threshold:
                peaks.append(i)

        merged = []
        for p in peaks:
            if not merged or (p - merged[-1]) > 18:
                merged.append(p)

        n = len(fx)
        y_span = round(float(fy[-1] - fy[0]), 1) if n > 1 else 0
        log(f"Y-profile peaks: {len(merged)}, arc y-span={y_span}px")

        face_indices = {}
        if len(merged) >= 3:
            face_indices["Forehead"] = merged[0]
            mid = merged[1:-1]
            face_indices["Nose Tip"] = max(mid, key=lambda i: fd_smooth[i])
            face_indices["Chin"] = merged[-1]
        elif len(merged) == 2:
            face_indices["Forehead"] = merged[0]
            face_indices["Nose Tip (Est)"] = merged[1]
        elif len(merged) == 1:
            face_indices["Nose Tip (Est)"] = merged[0]
        else:
            face_indices["Forehead"] = n // 8
            face_indices["Nose Tip (Est)"] = n // 2
            face_indices["Chin"] = n * 7 // 8

        for label_name, idx in face_indices.items():
            cx = float(fx[idx])
            cy = float(fy[idx])
            ix = int(np.clip(cx, 0, W - 1))
            iy = int(np.clip(cy, 0, H - 1))
            cz = float(h_map[iy, ix])
            landmarks[label_name] = (cx, cy, cz)
            log(f"Landmark [{label_name}] → ({cx:.1f}, {cy:.1f})")

    except Exception as e:
        log(f"Face landmark detection failed: {e}")

    return landmarks
