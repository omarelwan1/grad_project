import base64
import json
import urllib.request
import urllib.error
from pathlib import Path
from typing import Dict, Optional
from modules.logger import log

def encode_image_base64(path: Path) -> Optional[str]:
    """Helper to convert image files into base64 for embedding in HTML or sending to Gemini API."""
    if not path.exists():
        return None
    try:
        with open(path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")
    except Exception as e:
        log(f"Error encoding image to base64: {e}")
        return None

def query_gemini_api(api_key: str, model_name: str, prompt: str, base64_image: Optional[str] = None) -> str:
    """
    Sends the prompt (and optional base64 image) to Gemini API.
    Uses three layered strategies for maximum robustness:
      1. New google-genai SDK (recommended)
      2. Legacy google-generativeai SDK
      3. Direct standard HTTP request (completely bulletproof zero-dependency fallback)
    """
    # Clean up model name
    if "/" not in model_name:
        model_name = f"models/{model_name}"

    log(f"Attempting to query Gemini API ({model_name})...")

    # Strategy 1: google-genai (New SDK)
    try:
        from google import genai
        from google.genai import types
        log("Trying new google-genai SDK...")
        client = genai.Client(api_key=api_key)
        contents = [prompt]
        if base64_image:
            contents.append(
                types.Part.from_bytes(
                    data=base64.b64decode(base64_image),
                    mime_type="image/png"
                )
            )
        response = client.models.generate_content(
            model=model_name.replace("models/", ""),
            contents=contents,
        )
        if response.text:
            return response.text
    except Exception as e:
        log(f"google-genai SDK failed: {e}")

    # Strategy 2: google-generativeai (Legacy SDK)
    try:
        import google.generativeai as genai_legacy
        log("Trying legacy google-generativeai SDK...")
        genai_legacy.configure(api_key=api_key)
        model = genai_legacy.GenerativeModel(model_name.replace("models/", ""))
        
        contents = [prompt]
        if base64_image:
            contents.append({
                "mime_type": "image/png",
                "data": base64_image
            })
            
        response = model.generate_content(contents)
        if response.text:
            return response.text
    except Exception as e:
        log(f"google-generativeai legacy SDK failed: {e}")

    # Strategy 3: Standard HTTP Request (Zero-dependency fallback)
    log("Trying direct HTTP request fallback...")
    url = f"https://generativelanguage.googleapis.com/v1beta/{model_name}:generateContent?key={api_key}"
    
    # Construct request payload matching the Gemini API schema
    contents_part = [{"text": prompt}]
    if base64_image:
        contents_part.append({
            "inlineData": {
                "mimeType": "image/png",
                "data": base64_image
            }
        })
        
    payload = {
        "contents": [
            {
                "parts": contents_part
            }
        ],
        "generationConfig": {
            "temperature": 0.2,
            "topP": 0.95,
            "maxOutputTokens": 4096
        }
    }
    
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            res_body = response.read().decode("utf-8")
            res_json = json.loads(res_body)
            # Parse candidate text out
            text = res_json['candidates'][0]['content']['parts'][0]['text']
            return text
    except Exception as e:
        log(f"Direct HTTP API request failed: {e}")
        raise RuntimeError(
            "Gemini API request failed via all methods. "
            "Please check that your API Key is valid and you have internet access."
        ) from e

def generate_report(
    api_key: str,
    model_name: str,
    metrics: Dict,
    out_dir: Path,
    patient_id: str = "",
    gestational_age: str = "",
    clinical_notes: str = ""
) -> Path:
    """
    Generates a stunning clinical HTML report inside the given output folder.
    Leverages Gemini to produce detailed, clinical-grade visual interpretations and diagnostics.
    """
    log(f"Generating clinical report in {out_dir}")
    
    # 1. Identify stage image paths
    input_path = out_dir / "01_input.png"
    pre_path = out_dir / "02_preprocessed.png"
    mask_path = out_dir / "03_mask.png"
    preview_path = out_dir / "05_pseudovol_slices.png"
    
    # Get base64 representations for HTML embedding
    input_b64 = encode_image_base64(input_path) or ""
    pre_b64 = encode_image_base64(pre_path) or ""
    mask_b64 = encode_image_base64(mask_path) or ""
    preview_b64 = encode_image_base64(preview_path) or ""
    
    # Try to find mesh render preview if it exists
    mesh_preview_path = list(out_dir.glob("mesh_preview*.png"))
    # Or default to saving a static rendering of the mesh into the folder if we can render it.
    mesh_b64 = ""
    if mesh_preview_path:
        mesh_b64 = encode_image_base64(mesh_preview_path[0]) or ""
    else:
        # Check if there is an existing mesh preview image, otherwise use default
        for f in out_dir.iterdir():
            if "mesh" in f.name.lower() and f.suffix.lower() == ".png":
                mesh_b64 = encode_image_base64(f) or ""
                break

    # 2. Build the structured Prompt for Gemini
    prompt = f"""
    You are an expert Board-Certified Clinical Sonographer and Fetal Medicine Specialist specializing in advanced 3D obstetric ultrasound analysis and diagnostic reporting.
    The clinical operator has captured a 2D ultrasound scan and processed it through a spatial volumetric reconstruction model.
    The system computed the following quantitative metrics of the spatial boundary:
    
    [QUANTITATIVE VOLUMETRIC METRICS]
    - Spatial Silhouette Overlap (IoU): {metrics.get('silhouette_iou', 'N/A')}
    - Volumetric Mesh Elements (Triangles): {metrics.get('triangles', 'N/A')}
    - Computed Surface Points (Vertices): {metrics.get('vertices', 'N/A')}
    - Surface Uniformity & Quality Index: {metrics.get('mesh_quality', {}).get('shape_quality_mean', 'N/A')}
    - Boundary Area Metrics: {json.dumps(metrics.get('mesh_quality', {}), indent=2)}
    
    [CLINICAL SUBJECT METADATA]
    - Patient Identifier: {patient_id if patient_id else "ANONYMOUS/PROTOTYPE"}
    - Gestational Landmark Focus: {gestational_age if gestational_age else "Not Specified"}
    - Attending Physician Notes / Indications: {clinical_notes if clinical_notes else "None provided."}
    
    CRITICAL INSTRUCTION:
    Focus your analysis entirely on CLINICAL, ANATOMICAL, and DIAGNOSTIC sonography concepts. 
    AVOID talking about computer-graphics or computer science concepts (do NOT mention "Marching Cubes, computer rendering, Python pipelines, triangulation, 3D printing, vertex coordinates, or decimation algorithms"). 
    Instead, translate these engineering terms into diagnostic concepts:
    - Translate "Mesh Triangles / Vertices / Area" to "Anatomical surface area, physical volume boundaries, structural tissue morphology, or volumetric surface continuity."
    - Translate "Silhouette IoU / Uniformity" to "Reconstruction fidelity, anatomical contour continuity, boundary definition, or spatial landmark accuracy."
    
    TASK:
    Write a highly professional, clinical ultrasound report in beautiful, valid HTML. Do NOT return the full HTML page structure (no <html>, <head>, or <body> tags, nor CSS/styles), just output the core structured content inside a series of cleanly arranged CSS-ready blocks (such as <div class="card">, <h3>, <p>, <ul>, etc.) that we will inject into our template.
    
    Your report must contain these sections:
    1. **Anatomical Volumetric Assessment**: A deep diagnostic analysis of the physical tissue borders, boundary contour continuity, and physical surface morphology. Describe how the spatial depth of this reconstruction assists the clinician in tracking organic contours (e.g. tissue boundaries, skeletal curvature, or soft-tissue planes) compared to a simple, flat 2D projection.
    2. **Clinical Landmark & Boundary Fidelity**: An evaluation of the reconstruction fidelity (using the Spatial Overlap IoU of {metrics.get('silhouette_iou', 'N/A')} and Surface Uniformity of {metrics.get('mesh_quality', {}).get('shape_quality_mean', 'N/A')}). Explain what these values indicate about the integrity of the anatomical boundary and the precision of the volumetric tracking.
    3. **Diagnostic Insights & Clinical Utility**: Analyze how this spatial contour model benefits diagnostic validation, patient explanation, and gestational growth tracking (particularly for identifying structural asymmetry, cranial boundary shape, or soft-tissue profile continuity).
    4. **Recommendations & Attending Physician Directives**: Suggest next diagnostic follow-ups, clinical correlations (e.g., amniotic fluid index checks, target biometric sweeps, maternal-fetal serial scans), or parameter adjustments to optimize diagnostic scan capture.
    
    Use formal, comforting, yet highly advanced medical sonography terminology. Do not wrap the response in markdown code fences like ```html or ```. Just return the clean HTML content.
    """
    
    # 3. Query Gemini for the detailed clinical copy
    try:
        api_response = query_gemini_api(api_key, model_name, prompt, input_b64)
        # Strip any accidental markdown wrap
        if api_response.strip().startswith("```html"):
            api_response = api_response.strip()[7:]
        if api_response.strip().endswith("```"):
            api_response = api_response.strip()[:-3]
        api_response = api_response.strip()
    except Exception as e:
        log(f"Error querying Gemini: {e}")
        api_response = f"""
        <div class="alert warning">
            <h4>Gemini Report Generation Offline</h4>
            <p>The clinical description could not be completed via AI: {e}</p>
            <p>Please check your Gemini API key and network connection.</p>
        </div>
        """

    # 4. Generate the full interactive publication-grade HTML template
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Clinical Volumetric Report - Patient {patient_id if patient_id else "Anonymous"}</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg-base: #0f172a;
            --bg-card: rgba(30, 41, 59, 0.7);
            --bg-accent: rgba(148, 163, 184, 0.05);
            --border: rgba(255, 255, 255, 0.08);
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --primary: #38bdf8;
            --primary-glow: rgba(56, 189, 248, 0.2);
            --success: #34d399;
            --warning: #fbbf24;
        }}

        @media (prefers-color-scheme: light) {{
            :root {{
                --bg-base: #f8fafc;
                --bg-card: rgba(255, 255, 255, 0.85);
                --bg-accent: rgba(15, 23, 42, 0.03);
                --border: rgba(15, 23, 42, 0.08);
                --text-primary: #0f172a;
                --text-secondary: #475569;
                --primary: #0284c7;
                --primary-glow: rgba(2, 132, 199, 0.15);
                --success: #16a34a;
                --warning: #d97706;
            }}
        }}

        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}

        body {{
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-base);
            color: var(--text-primary);
            line-height: 1.6;
            padding: 2.5rem 1.5rem;
            min-height: 100vh;
            background-image: radial-gradient(circle at 10% 20%, var(--primary-glow) 0%, transparent 40%),
                              radial-gradient(circle at 90% 80%, rgba(52, 211, 153, 0.05) 0%, transparent 40%);
            background-attachment: fixed;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}

        header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--border);
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            gap: 1.5rem;
        }}

        .logo-area {{
            display: flex;
            align-items: center;
            gap: 1rem;
        }}

        .logo-badge {{
            background: linear-gradient(135deg, var(--primary), var(--success));
            color: #ffffff;
            width: 3.5rem;
            height: 3.5rem;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 800;
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.3);
        }}

        .title-group h1 {{
            font-size: 1.75rem;
            font-weight: 800;
            letter-spacing: -0.025em;
            background: linear-gradient(to right, var(--text-primary), var(--text-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}

        .title-group p {{
            font-size: 0.875rem;
            color: var(--text-secondary);
        }}

        .actions-area {{
            display: flex;
            gap: 0.75rem;
        }}

        .btn {{
            padding: 0.625rem 1.25rem;
            border-radius: 8px;
            font-size: 0.875rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            text-decoration: none;
            border: 1px solid var(--border);
        }}

        .btn-primary {{
            background-color: var(--primary);
            color: #ffffff;
            border: none;
            box-shadow: 0 4px 12px var(--primary-glow);
        }}

        .btn-primary:hover {{
            transform: translateY(-1px);
            box-shadow: 0 6px 16px var(--primary-glow);
            filter: brightness(1.1);
        }}

        .btn-secondary {{
            background-color: var(--bg-card);
            color: var(--text-primary);
        }}

        .btn-secondary:hover {{
            background-color: var(--bg-accent);
            transform: translateY(-1px);
        }}

        .grid-metadata {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.25rem;
            margin-bottom: 2.5rem;
        }}

        .meta-card {{
            background-color: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.25rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.03);
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }}

        .meta-label {{
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-secondary);
            font-weight: 700;
        }}

        .meta-value {{
            font-size: 1.125rem;
            font-weight: 700;
            color: var(--text-primary);
        }}

        .layout-main {{
            display: grid;
            grid-template-columns: 3fr 2fr;
            gap: 2rem;
        }}

        @media (max-width: 968px) {{
            .layout-main {{
                grid-template-columns: 1fr;
            }}
        }}

        .section-panel {{
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }}

        .card {{
            background-color: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 2rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.02);
            position: relative;
            overflow: hidden;
        }}

        .card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), transparent);
            opacity: 0.4;
        }}

        .card h2 {{
            font-size: 1.25rem;
            font-weight: 800;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            letter-spacing: -0.01em;
        }}

        .card h3 {{
            font-size: 1.05rem;
            font-weight: 700;
            margin-top: 1.25rem;
            margin-bottom: 0.5rem;
            color: var(--primary);
        }}

        .card p {{
            font-size: 0.95rem;
            color: var(--text-primary);
            opacity: 0.9;
            margin-bottom: 1rem;
            line-height: 1.7;
        }}

        .card ul {{
            margin-left: 1.25rem;
            margin-bottom: 1.25rem;
            font-size: 0.95rem;
            color: var(--text-primary);
            opacity: 0.9;
        }}

        .card li {{
            margin-bottom: 0.5rem;
        }}

        .gallery-container {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.25rem;
            margin-bottom: 1.5rem;
        }}

        @media (max-width: 580px) {{
            .gallery-container {{
                grid-template-columns: 1fr;
            }}
        }}

        .image-frame {{
            background-color: var(--bg-accent);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 0.75rem;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }}

        .image-frame img {{
            width: 100%;
            height: auto;
            border-radius: 8px;
            display: block;
            background-color: #000000;
        }}

        .image-caption {{
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-align: center;
        }}

        .metric-row {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--border);
            font-size: 0.9rem;
        }}

        .metric-row:last-child {{
            border-bottom: none;
        }}

        .metric-name {{
            color: var(--text-secondary);
            font-weight: 500;
        }}

        .metric-val {{
            font-weight: 700;
            font-family: monospace;
            color: var(--text-primary);
        }}

        .tag {{
            padding: 0.25rem 0.625rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
        }}

        .tag-success {{
            background-color: rgba(52, 211, 153, 0.15);
            color: var(--success);
        }}

        .tag-primary {{
            background-color: var(--primary-glow);
            color: var(--primary);
        }}

        .alert {{
            padding: 1rem 1.25rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }}

        .alert.warning {{
            background-color: rgba(251, 191, 36, 0.1);
            border: 1px solid rgba(251, 191, 36, 0.2);
            color: var(--warning);
        }}

        @media print {{
            body {{
                background-color: #ffffff !important;
                color: #000000 !important;
                padding: 0 !important;
            }}
            .card {{
                box-shadow: none !important;
                border: 1px solid #e2e8f0 !important;
                background-color: #ffffff !important;
                page-break-inside: avoid;
            }}
            .btn, .actions-area {{
                display: none !important;
            }}
            header {{
                margin-bottom: 1.5rem !important;
                padding-bottom: 1rem !important;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo-area">
                <div class="logo-badge">3D</div>
                <div class="title-group">
                    <h1>AI Volumetric Clinical Analysis</h1>
                    <p>Ultrasound 2D &rarr; Pseudo‑3D &rarr; Surface Mesh Reconstruction</p>
                </div>
            </div>
            <div class="actions-area">
                <button class="btn btn-secondary" onclick="window.print()">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2m-2-4v8H8v-8"></path></svg>
                    Print Report
                </button>
            </div>
        </header>

        <div class="grid-metadata">
            <div class="meta-card">
                <span class="meta-label">Patient ID</span>
                <span class="meta-value">{patient_id if patient_id else "Anonymous"}</span>
            </div>
            <div class="meta-card">
                <span class="meta-label">Gestational Age</span>
                <span class="meta-value">{gestational_age if gestational_age else "N/A"}</span>
            </div>
            <div class="meta-card">
                <span class="meta-label">Date of Analysis</span>
                <span class="meta-value" id="current-date">--/--/----</span>
            </div>
            <div class="meta-card">
                <span class="meta-label">Pipeline Status</span>
                <span class="meta-value"><span class="tag tag-success">Completed</span></span>
            </div>
        </div>

        <div class="layout-main">
            <!-- Left Panel: AI Report and Pipeline Visuals -->
            <div class="section-panel">
                <div class="card">
                    <h2>
                        <svg width="20" height="20" fill="none" stroke="var(--primary)" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        Physician Clinical Summary (AI Generated)
                    </h2>
                    {api_response}
                </div>

                <div class="card">
                    <h2>
                        <svg width="20" height="20" fill="none" stroke="var(--primary)" stroke-width="2.5" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        Pipeline Stage Visualizations
                    </h2>
                    
                    <div class="gallery-container">
                        <div class="image-frame">
                            <img src="data:image/png;base64,{input_b64}" alt="Input 2D Ultrasound">
                            <div class="image-caption">01. Input 2D Ultrasound</div>
                        </div>
                        <div class="image-frame">
                            <img src="data:image/png;base64,{pre_b64}" alt="Denoised & Filtered">
                            <div class="image-caption">02. Denoised & Anisotropic Diffused</div>
                        </div>
                        <div class="image-frame">
                            <img src="data:image/png;base64,{mask_b64}" alt="Segmented Fetal Mask">
                            <div class="image-caption">03. Target Segmented Mask</div>
                        </div>
                        <div class="image-frame">
                            <img src="data:image/png;base64,{preview_b64}" alt="Pseudo-3D Volume Slices">
                            <div class="image-caption">04. Volumetric Depth Projection Slices</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Panel: Reconstructed 3D Mesh and Stats -->
            <div class="section-panel">
                <div class="card">
                    <h2>
                        <svg width="20" height="20" fill="none" stroke="var(--primary)" stroke-width="2.5" viewBox="0 0 24 24"><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                        3D Mesh Reconstruction Preview
                    </h2>
                    
                    <div class="image-frame" style="margin-bottom: 1.5rem;">
                        <img src="data:image/png;base64,{mesh_b64}" alt="3D Surface Mesh Rendering">
                        <div class="image-caption">Matplotlib Isometric Mesh Surface View</div>
                    </div>

                    <div class="metric-row">
                        <span class="metric-name">Silhouette Overlap (IoU)</span>
                        <span class="metric-val" style="color: var(--success); font-weight: bold;">{(metrics.get('silhouette_iou', 0) * 100):.2f}%</span>
                    </div>
                    <div class="metric-row">
                        <span class="metric-name">Total Face Triangles</span>
                        <span class="metric-val">{metrics.get('triangles', 0):,}</span>
                    </div>
                    <div class="metric-row">
                        <span class="metric-name">Total Vertices</span>
                        <span class="metric-val">{metrics.get('vertices', 0):,}</span>
                    </div>
                    <div class="metric-row">
                        <span class="metric-name">Average Face Area</span>
                        <span class="metric-val">{metrics.get('mesh_quality', {}).get('triangle_area_mean', 0):.4f}</span>
                    </div>
                    <div class="metric-row">
                        <span class="metric-name">Edge Length Consistency (Std Dev)</span>
                        <span class="metric-val">{metrics.get('mesh_quality', {}).get('edge_len_std', 0):.4f}</span>
                    </div>
                    <div class="metric-row">
                        <span class="metric-name">Mean Shape Quality Index</span>
                        <span class="metric-val">{metrics.get('mesh_quality', {}).get('shape_quality_mean', 0):.4f}</span>
                    </div>
                    <div class="metric-row">
                        <span class="metric-name">Pipeline Computation Time</span>
                        <span class="metric-val">{metrics.get('runtime_seconds', 0.0):.3f}s</span>
                    </div>
                </div>

                <div class="card" style="padding: 1.5rem;">
                    <h2>
                        <svg width="20" height="20" fill="none" stroke="var(--primary)" stroke-width="2.5" viewBox="0 0 24 24"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        Technical Insights
                    </h2>
                    <p style="font-size: 0.85rem; margin-bottom: 0.75rem;">
                        <strong>Silhouette IoU:</strong> Evaluates how accurately the projected 3D volume envelope aligns with the 2D bounding anatomy mask. Over 45% represents an exceptionally precise matching cube extraction.
                    </p>
                    <p style="font-size: 0.85rem;">
                        <strong>Mean Shape Quality Index:</strong> A value closer to 0.33 represents perfectly uniform equilateral triangles, which minimizes computational artifact spikes in downstream CAD/3D prints.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('current-date').innerText = new Date().toLocaleDateString(undefined, {{
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        }});
    </script>
</body>
</html>
"""
    
    # 5. Save the compiled report file
    report_path = out_dir / "clinical_report.html"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        log(f"Stunning clinical report successfully written to: {report_path}")
    except Exception as e:
        log(f"Failed to write clinical report HTML file: {e}")
        raise
        
    return report_path
