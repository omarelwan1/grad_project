
from skimage.feature import canny

def extract_edges(img01, cfg: dict):
    sigma = float(cfg.get("sigma", 1.5))
    low = cfg.get("low_threshold", None)
    high = cfg.get("high_threshold", None)
    edges = canny(img01, sigma=sigma, low_threshold=low, high_threshold=high)
    return edges.astype("uint8")
