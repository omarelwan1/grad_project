from __future__ import annotations
from pathlib import Path
import datetime

def get_log_path() -> Path:
    root = Path.cwd() / "auto_outputs"
    root.mkdir(parents=True, exist_ok=True)
    return root / "app.log"

def log(msg: str) -> None:
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}\n"
    try:
        p = get_log_path()
        with open(p, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
