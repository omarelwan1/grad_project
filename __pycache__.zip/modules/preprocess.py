import numpy as np
from scipy.ndimage import median_filter
from skimage.restoration import denoise_bilateral

def normalize01(img: np.ndarray) -> np.ndarray:
    img = img.astype(np.float32)
    mn, mx = float(img.min()), float(img.max())
    if mx - mn < 1e-8:
        return np.zeros_like(img, dtype=np.float32)
    return (img - mn) / (mx - mn)

def perona_malik_diffusion(img01: np.ndarray, niter: int = 10, kappa: float = 0.08, gamma: float = 0.15) -> np.ndarray:
    '''
    Perona-Malik anisotropic diffusion on an image in [0,1].
    NOTE: kappa should be ~0.05-0.2 for [0,1] images (not 25).
    '''
    I = img01.astype(np.float32).copy()
    if float(I.max() - I.min()) < 1e-8:
        return np.clip(I, 0.0, 1.0)

    for _ in range(int(niter)):
        # Differences to neighbors (classic formulation)
        dN = np.zeros_like(I); dS = np.zeros_like(I); dE = np.zeros_like(I); dW = np.zeros_like(I)
        dN[1:, :]  = I[:-1, :] - I[1:, :]
        dS[:-1, :] = I[1:, :]  - I[:-1, :]
        dW[:, 1:]  = I[:, :-1] - I[:, 1:]
        dE[:, :-1] = I[:, 1:]  - I[:, :-1]

        kk = float(kappa) + 1e-9
        cN = np.exp(-(dN / kk) ** 2)
        cS = np.exp(-(dS / kk) ** 2)
        cE = np.exp(-(dE / kk) ** 2)
        cW = np.exp(-(dW / kk) ** 2)

        I = I + float(gamma) * (cN * dN + cS * dS + cE * dE + cW * dW)

    return np.clip(I, 0.0, 1.0)

def despeckle(img01: np.ndarray, median_size: int = 3, use_bilateral: bool = True,
              bilateral_sigma_color: float = 0.08, bilateral_sigma_spatial: float = 3.0) -> np.ndarray:
    '''
    Practical speckle reduction for ultrasound:
      1) small median filter to remove impulse-like noise
      2) bilateral filter to smooth while preserving edges
      3) optional Perona-Malik diffusion afterward (done in pipeline_runner)
    '''
    x = np.clip(img01.astype(np.float32), 0.0, 1.0)

    if int(median_size) >= 3:
        x = median_filter(x, size=int(median_size))

    if bool(use_bilateral):
        x = denoise_bilateral(
            x,
            sigma_color=float(bilateral_sigma_color),
            sigma_spatial=float(bilateral_sigma_spatial),
            channel_axis=None
        ).astype(np.float32)

    return np.clip(x, 0.0, 1.0)
