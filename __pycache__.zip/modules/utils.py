
from __future__ import annotations
from pathlib import Path
from typing import List
import numpy as np
from PIL import Image

IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def list_images(folder: Path) -> List[Path]:
    files = []
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in IMG_EXTS:
            files.append(p)
    return files

def save_image(path: Path, arr_uint8: np.ndarray) -> None:
    Image.fromarray(arr_uint8).save(str(path))

def normalize01(x: np.ndarray) -> np.ndarray:
    x = x.astype(np.float32)
    mn, mx = float(np.min(x)), float(np.max(x))
    if mx - mn < 1e-8:
        return np.zeros_like(x, dtype=np.float32)
    return (x - mn) / (mx - mn)

def to_uint8(x01_or_u8: np.ndarray) -> np.ndarray:
    if x01_or_u8.dtype == np.uint8:
        return x01_or_u8
    x = np.clip(x01_or_u8, 0.0, 1.0)
    return (x * 255.0 + 0.5).astype(np.uint8)

def resize_keep_aspect_pad(img: np.ndarray, target: int) -> np.ndarray:
    h, w = img.shape[:2]
    if h == 0 or w == 0:
        return np.zeros((target, target), dtype=np.float32)
    scale = target / max(h, w)
    new_h, new_w = int(round(h * scale)), int(round(w * scale))
    pil = Image.fromarray(img.astype(np.uint8)) if img.dtype != np.uint8 else Image.fromarray(img)
    pil = pil.resize((new_w, new_h), resample=Image.BILINEAR)
    arr = np.asarray(pil, dtype=np.float32)
    canvas = np.zeros((target, target), dtype=np.float32)
    y0 = (target - new_h) // 2
    x0 = (target - new_w) // 2
    canvas[y0:y0+new_h, x0:x0+new_w] = arr
    return canvas
