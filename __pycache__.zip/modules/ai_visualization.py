
import os
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
import numpy as np
from pathlib import Path
from modules.logger import log

def generate_ai_scan(landmarks: dict, original_img_path: Path) -> Image.Image:
    """
    Takes the original 2D ultrasound image and overlays the detected anatomical 
    features (Forehead, Nose Tip, Chin, Head Center) directly onto it, boosting
    their visibility using professional medical contrast enhancement, neon callouts,
    and targeted pointer guides.

    This ensures the output is 100% faithful to the patient's actual scan 
    while making obscure biological structures clearly visible.
    """
    if not original_img_path.exists():
        raise FileNotFoundError(f"Original ultrasound image not found at {original_img_path}")

    log(f"Loading original ultrasound for overlay: {original_img_path}")
    img = Image.open(original_img_path).convert("L")
    W, H = img.size

    # 1. Boost contrast/brightness locally to make bone reflections and boundaries pop
    enhancer = ImageEnhance.Contrast(img)
    img_enhanced = enhancer.enhance(1.4)  # Boost overall structural contrast
    
    # Convert to RGB to support neon clinical highlights
    img_rgb = img_enhanced.convert("RGB")
    draw = ImageDraw.Draw(img_rgb, "RGBA")

    # Try to load a clean clinical font, otherwise fallback to default
    try:
        # standard Windows font, highly readable
        font = ImageFont.truetype("arial.ttf", 14)
        title_font = ImageFont.truetype("arial.ttf", 16)
    except IOError:
        font = ImageFont.load_default()
        title_font = ImageFont.load_default()

    # 2. Draw anatomical markers and guide arrows
    colors_map = {
        "Head Center": (255, 0, 255, 255),      # Neon Magenta
        "Nose Tip": (255, 170, 0, 255),         # Vibrant Orange
        "Nose Tip (Est)": (255, 170, 0, 255),
        "Forehead": (0, 255, 255, 255),         # Neon Cyan
        "Chin": (0, 255, 0, 255)                # Neon Green
    }

    # Outline sequence connecting Forehead -> Nose Tip -> Chin to highlight facial profile
    profile_points = []
    for name in ["Forehead", "Nose Tip", "Nose Tip (Est)", "Chin"]:
        if name in landmarks:
            pos = landmarks[name]
            profile_points.append((pos[0], pos[1]))

    # Draw face profile silhouette guide line if we have at least 2 points
    if len(profile_points) >= 2:
        # Sort points by y-coordinate to connect them in order
        profile_points = sorted(profile_points, key=lambda p: p[1])
        draw.line(profile_points, fill=(255, 255, 0, 180), width=3)  # Translucent neon yellow guide

    # Draw individual landmark highlights and pointer boxes
    for name, pos in landmarks.items():
        lx, ly = int(pos[0]), int(pos[1])
        color = colors_map.get(name, (255, 50, 50, 255))
        
        # A. Draw target crosshair and ring
        draw.ellipse([lx - 8, ly - 8, lx + 8, ly + 8], outline=color, width=2)
        draw.ellipse([lx - 2, ly - 2, lx + 2, ly + 2], fill=color)
        # Crosshair hairs
        draw.line([lx - 12, ly, lx + 12, ly], fill=color, width=1)
        draw.line([lx, ly - 12, lx, ly + 12], fill=color, width=1)

        # B. Draw pointer label with a clean offset callout line
        # Choose label placement based on which side of the image we are on
        dx = 55 if lx < W / 2 else -160
        dy = -35 if ly > H / 2 else 35
        
        tx, ty = lx + dx, ly + dy
        # Callout line
        draw.line([lx, ly, tx, ty], fill=(255, 255, 255, 150), width=2)
        
        # Text background badge for high visibility
        text_w = len(name) * 8 + 12
        text_h = 22
        draw.rectangle([tx - 4, ty - 2, tx + text_w, ty + text_h], fill=(16, 16, 42, 220), outline=color, width=2)
        
        # Text label
        draw.text((tx, ty + 1), name, fill=(255, 255, 255, 255), font=font)

    # 3. Add Clinical Info Header
    draw.rectangle([0, 0, W, 35], fill=(16, 16, 42, 230))
    draw.text((15, 8), "FETAL ULTRASOUND FEATURES HIGHLIGHTED", fill=(0, 255, 255), font=title_font)
    
    log("Annotated ultrasound overlay completed successfully!")
    return img_rgb
