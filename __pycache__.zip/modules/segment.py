
import numpy as np
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

from skimage.morphology import closing, disk
from scipy.ndimage import binary_fill_holes, gaussian_filter
from skimage.measure import label, regionprops


def _keep_largest_component(mask: np.ndarray) -> np.ndarray:
    lbl = label(mask)
    if lbl.max() == 0:
        return mask.astype(bool)
    regs = regionprops(lbl)
    best = max(regs, key=lambda r: r.area)
    return (lbl == best.label)


def segment_mask(img01: np.ndarray, cfg: dict) -> np.ndarray:
    """
    Extract the valid ultrasound scan region (wedge/fan).

    Strategy:
    ─────────
    Rather than trying to isolate individual anatomical structures with
    a hard brightness threshold (which always degrades to selecting the whole
    fan OR tiny noise fragments), we now return the *entire US scan cone*
    as the mask.  The 3D shape is entirely driven by pixel brightness in
    pseudovolume.py — bright = tall peak, dark = shallow. This faithfully
    follows every feature in the sonar rather than discarding them.

    Only the absolute black surround (scanner border) is excluded.
    """
    scan_thresh = float(cfg.get("scan_thresh", 0.05))
    morph_radius = int(cfg.get("morph_radius", 5))

    # 1. Anything above the near-zero background threshold is "inside scan"
    scan = (img01 > scan_thresh)

    # 2. Close small holes and gaps in the wedge boundary
    scan = closing(scan, disk(morph_radius))
    scan = binary_fill_holes(scan)

    # 3. Keep only the largest connected region (the US fan itself)
    scan = _keep_largest_component(scan)

    # 4. Final gentle dilation to recover thin edge pixels
    scan = closing(scan, disk(2))

    return scan.astype(np.uint8)
