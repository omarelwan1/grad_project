
import numpy as np
from scipy.ndimage import gaussian_filter, distance_transform_edt


# ── Hessian ridge helper ──────────────────────────────────────────────────── #

def _hessian_ridges(img: np.ndarray, sigma: float = 2.5) -> np.ndarray:
    """
    Detect bright ridges (skull outline, spine, ribs) via the Hessian matrix.

    Returns a [0,1] map where 1.0 = strong anatomical ridge.
    These pixels are pushed to the highest Z positions in the volume.
    """
    # Gaussian derivatives
    from scipy.ndimage import gaussian_filter as gf
    img_s = gf(img, sigma=sigma)
    # Hessian components via finite differences on the Gaussian-smoothed image
    Hxx = gf(np.gradient(np.gradient(img_s, axis=1), axis=1), sigma=sigma * 0.5)
    Hyy = gf(np.gradient(np.gradient(img_s, axis=0), axis=0), sigma=sigma * 0.5)
    Hxy = gf(np.gradient(np.gradient(img_s, axis=1), axis=0), sigma=sigma * 0.5)

    # Eigenvalues of 2×2 symmetric matrix
    trace = Hxx + Hyy
    det   = Hxx * Hyy - Hxy ** 2
    disc  = np.sqrt(np.clip(0.25 * trace ** 2 - det, 0.0, None))
    lam2  = 0.5 * trace + disc   # larger eigenvalue

    # Bright ridges: large *negative* lam2 (concave-up curvature)
    ridge = np.clip(-lam2, 0.0, None)
    if ridge.max() > 1e-9:
        ridge = ridge / ridge.max()
    return ridge.astype(np.float32)


# ── Main pseudovolume builder ─────────────────────────────────────────────── #

def build_pseudovolume(img01: np.ndarray, mask01: np.ndarray, cfg: dict) -> np.ndarray:
    """
    Build a 3-D voxel volume from a 2-D ultrasound frame.

    MODE: layered_anatomy (default)
    ────────────────────────────────────────────────────────────
    Three signals are combined to create anatomically stratified depth:

      1. Hessian ridge map  — bone, skull dome, spine → tallest peaks
      2. Pixel brightness   — tissue strength → medium elevation
      3. Distance-field     — interior of scan region → body volume "inflation"

    The result is a multi-shell volume where:
      • The skull/spine rise as sharp 3-D ridges at the top
      • The soft-tissue body fills a medium elevation layer
      • A filled "body base" gives the whole thing 3-D volume (not just terrain)
    """
    mode = cfg.get("mode", "layered_anatomy")
    Z    = int(cfg.get("z_slices", 96))

    img = img01.astype(np.float32)
    m   = (mask01 > 0).astype(np.float32)

    # ── Shared preprocessing ──────────────────────────────────────────── #
    smooth_sigma      = float(cfg.get("depth_smooth_sigma", 2.0))
    ridge_sigma       = float(cfg.get("ridge_sigma", 2.5))
    ridge_weight      = float(cfg.get("ridge_weight", 0.35))
    body_lift_str     = float(cfg.get("body_lift_strength", 0.25))
    body_base_frac    = float(cfg.get("body_base_fraction", 0.28))
    shell_thickness   = float(cfg.get("shell_thickness", 0.20))
    depth_gamma       = float(cfg.get("depth_gamma", 1.05))

    # Soft mask boundary tapering
    m_soft = gaussian_filter(m, sigma=2.5)
    if m_soft.max() > 1e-9:
        m_soft = m_soft / m_soft.max()
    m_soft = np.clip(m_soft, 0.0, 1.0)

    # Smooth + locally-normalised brightness
    img_sm = gaussian_filter(img, sigma=smooth_sigma)
    local_max = gaussian_filter(img_sm + 1e-6, sigma=18.0)
    img_norm = np.clip(img_sm / local_max, 0.0, 1.0) * m_soft

    # ── ① Hessian ridge map ───────────────────────────────────────────── #
    ridge = _hessian_ridges(img, sigma=ridge_sigma) * m_soft

    # ── ② Distance-field body inflation ──────────────────────────────── #
    dist = distance_transform_edt(m).astype(np.float32)
    if dist.max() > 1e-9:
        dist_n = dist / dist.max()
    else:
        dist_n = dist
    dist_n = dist_n * m_soft

    # ── Composite depth map ───────────────────────────────────────────── #
    # ridge_weight + body_lift_str must leave some room for brightness
    bright_w = max(0.0, 1.0 - ridge_weight - body_lift_str)
    depth = (bright_w   * img_norm
           + ridge_weight * ridge
           + body_lift_str * dist_n)
    depth = np.power(np.clip(depth, 0.0, 1.0), depth_gamma)
    depth = depth * m_soft   # mask out scanner border

    # ── ③ Build layered volume ────────────────────────────────────────── #
    z_center = depth * (Z - 1)               # (H, W)
    half_shell = shell_thickness * Z * 0.5
    sigma_z    = max(half_shell / 2.0, 1.5)

    vol = np.zeros((Z, img.shape[0], img.shape[1]), dtype=np.float32)
    for z in range(Z):
        z_frac = z / float(Z - 1)

        # Primary shell: Gaussian around each pixel's z_center
        dist_to_center = np.abs(z - z_center)
        shell_w = np.exp(-0.5 * (dist_to_center / sigma_z) ** 2)
        amplitude = np.clip(depth * m_soft * 1.8, 0.0, 1.0)

        # Body base: fills volume from z=0 up to body_base_frac of the range
        # weighted by distance from boundary so edges taper naturally
        if z_frac <= body_base_frac:
            # Cosine taper so the base blends smoothly into the shell
            taper = 0.5 * (1.0 + np.cos(np.pi * z_frac / body_base_frac))
            base_fill = dist_n * taper * 0.60
        else:
            base_fill = np.zeros_like(dist_n)

        vol[z] = np.clip(shell_w * amplitude + base_fill, 0.0, 1.0)

    return vol.astype(np.float32)


# ── Slice preview helper ──────────────────────────────────────────────────── #

def make_volume_slices_preview(volume: np.ndarray, n_slices: int = 9) -> np.ndarray:
    Z, H, W = volume.shape
    n_slices = max(1, int(n_slices))
    idx  = np.linspace(0, Z - 1, n_slices).round().astype(int)
    cols = int(np.ceil(np.sqrt(n_slices)))
    rows = int(np.ceil(n_slices / cols))
    canvas = np.zeros((rows * H, cols * W), dtype=np.float32)
    for i, z in enumerate(idx):
        r = i // cols
        c = i % cols
        canvas[r*H:(r+1)*H, c*W:(c+1)*W] = volume[z]
    return canvas
