
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from skimage.measure import marching_cubes

try:
    import trimesh
    try:
        from trimesh.smoothing import filter_laplacian
    except Exception:
        filter_laplacian = None
except Exception:
    trimesh = None
    filter_laplacian = None


@dataclass
class SimpleMesh:
    vertices: np.ndarray
    faces: np.ndarray

    def export_ply(self, path: str) -> None:
        v = self.vertices
        f = self.faces
        with open(path, "w", encoding="utf-8") as fp:
            fp.write("ply\nformat ascii 1.0\n")
            fp.write(f"element vertex {len(v)}\n")
            fp.write("property float x\nproperty float y\nproperty float z\n")
            fp.write(f"element face {len(f)}\n")
            fp.write("property list uchar int vertex_indices\n")
            fp.write("end_header\n")
            for x, y, z in v:
                fp.write(f"{x} {y} {z}\n")
            for tri in f:
                fp.write(f"3 {int(tri[0])} {int(tri[1])} {int(tri[2])}\n")


def _empty_mesh():
    return SimpleMesh(vertices=np.zeros((0, 3), dtype=np.float32),
                      faces=np.zeros((0, 3), dtype=np.int32))


def extract_mesh_marching_cubes(volume_zyx: np.ndarray, level: float = 0.18, vol_cfg=None) -> SimpleMesh:
    vol = volume_zyx.astype(np.float32)
    vmin = float(np.nanmin(vol))
    vmax = float(np.nanmax(vol))
    if not np.isfinite(vmin) or not np.isfinite(vmax):
        return _empty_mesh()
    if vmax - vmin < 1e-6:
        return _empty_mesh()

    auto_iso = True
    min_iso_fraction = 0.35
    if vol_cfg is not None:
        auto_iso = bool(vol_cfg.get("auto_iso", True))
        min_iso_fraction = float(vol_cfg.get("min_iso_fraction", 0.35))

    lvl = float(level)
    if auto_iso:
        if not (vmin < lvl < vmax):
            lvl = vmin + min_iso_fraction * (vmax - vmin)
        eps = 1e-5 * (vmax - vmin)
        lvl = min(max(lvl, vmin + eps), vmax - eps)
    else:
        if not (vmin < lvl < vmax):
            return _empty_mesh()

    try:
        verts, faces, _n, _v = marching_cubes(vol, level=lvl)
    except Exception:
        return _empty_mesh()

    # marching_cubes returns (z,y,x) verts for (Z,Y,X) volume
    v_xyz = np.stack([verts[:, 2], verts[:, 1], verts[:, 0]], axis=1).astype(np.float32)
    return SimpleMesh(vertices=v_xyz, faces=faces.astype(np.int32))


def _safe_call(obj, name: str, *args, **kwargs):
    fn = getattr(obj, name, None)
    if callable(fn):
        try:
            return fn(*args, **kwargs)
        except Exception:
            return None
    return None


def _keep_largest_component_trimesh(mesh):
    split_fn = getattr(mesh, "split", None)
    if not callable(split_fn):
        return mesh
    try:
        parts = mesh.split(only_watertight=False)
    except Exception:
        try:
            parts = mesh.split()
        except Exception:
            return mesh
    if not parts:
        return mesh
    parts = sorted(parts, key=lambda m: m.faces.shape[0], reverse=True)
    return parts[0]


def _bilateral_smooth(vertices: np.ndarray, faces: np.ndarray,
                      iterations: int = 4, sigma_n: float = 0.5,
                      lam: float = 0.40) -> np.ndarray:
    """
    Feature-preserving bilateral Laplacian smoothing.

    Each vertex is pulled toward the weighted average of its one-ring
    neighbours. Weight = exp(-|n_i · n_j - 1|² / (2 σ_n²)), so
    neighbours whose face normals align with the current face get full
    weight, and neighbours across a sharp crease (skull / spine ridge)
    get near-zero weight.  This keeps anatomical edges crisp while
    smoothing out marching-cubes staircasing on curved surfaces.
    """
    v = vertices.copy()
    f = faces.astype(np.int64)

    # Build vertex → faces adjacency once
    n_verts = len(v)
    v2f = [[] for _ in range(n_verts)]
    for fi, tri in enumerate(f):
        for vi in tri:
            v2f[vi].append(fi)

    # Face normals helper
    def _face_normals(verts):
        e1 = verts[f[:, 1]] - verts[f[:, 0]]
        e2 = verts[f[:, 2]] - verts[f[:, 0]]
        n  = np.cross(e1, e2)
        nlen = np.linalg.norm(n, axis=1, keepdims=True) + 1e-9
        return n / nlen   # (F, 3) unit normals

    for _ in range(iterations):
        fn = _face_normals(v)   # (F, 3)

        new_v = v.copy()
        for vi in range(n_verts):
            fi_list = v2f[vi]
            if not fi_list:
                continue
            # Average normal of faces touching this vertex
            ni = fn[fi_list].mean(axis=0)
            ni_norm = np.linalg.norm(ni)
            if ni_norm < 1e-9:
                continue
            ni /= ni_norm

            # Collect one-ring neighbours
            nbrs = set()
            for fi in fi_list:
                for vj in f[fi]:
                    if vj != vi:
                        nbrs.add(vj)
            if not nbrs:
                continue

            # Weighted Laplacian
            w_sum   = 0.0
            wv_sum  = np.zeros(3, dtype=np.float64)
            for vj in nbrs:
                # Faces shared between vi and vj
                shared = [fk for fk in v2f[vi] if vj in f[fk]]
                if not shared:
                    nj = ni
                else:
                    nj = fn[shared].mean(axis=0)
                    nj_n = np.linalg.norm(nj)
                    if nj_n > 1e-9:
                        nj /= nj_n
                dot = float(np.clip(np.dot(ni, nj), -1.0, 1.0))
                w = np.exp(-((dot - 1.0) ** 2) / (2.0 * sigma_n ** 2))
                w_sum  += w
                wv_sum += w * v[vj]

            if w_sum > 1e-9:
                target = wv_sum / w_sum
                new_v[vi] = (1.0 - lam) * v[vi] + lam * target

        v = new_v
    return v.astype(np.float32)


def postprocess_mesh(mesh: SimpleMesh, cfg: dict) -> SimpleMesh:
    '''
    Post-processing pipeline for the marching-cubes mesh:
      1. Cleanup (degenerate faces, duplicates)
      2. Keep largest component (optional)
      3. Quadric decimation
      4. Smoothing — "bilateral" (feature-preserving) or "laplacian" (fast)
    '''
    if mesh.faces.size == 0 or mesh.vertices.size == 0:
        return mesh
    if trimesh is None:
        return mesh

    keep_largest  = bool(cfg.get("keep_largest_component", False))
    smooth_enabled = bool(cfg.get("smooth_enabled", True))
    smooth_iters  = int(cfg.get("smooth_iters", 4))
    smooth_lambda = float(cfg.get("smooth_lambda", 0.35))
    smooth_mode   = str(cfg.get("smooth_mode", "bilateral"))

    try:
        tm = trimesh.Trimesh(mesh.vertices, mesh.faces, process=False)
    except Exception:
        return mesh

    _safe_call(tm, "remove_infinite_values")
    _safe_call(tm, "remove_degenerate_faces")
    _safe_call(tm, "remove_duplicate_faces")
    _safe_call(tm, "remove_unreferenced_vertices")
    _safe_call(tm, "process", validate=True)

    if keep_largest:
        tm = _keep_largest_component_trimesh(tm)

    # Decimation
    decimate_enabled = bool(cfg.get("decimate_enabled", True))
    decimate_ratio   = float(cfg.get("decimate_ratio", 0.18))
    if decimate_enabled and tm.faces.size > 0:
        simplify_fn = getattr(tm, "simplify_quadric_decimation", None)
        if callable(simplify_fn):
            try:
                target_faces = max(2000, int(len(tm.faces) * decimate_ratio))
                if target_faces < len(tm.faces):
                    decimated = simplify_fn(face_count=target_faces)
                    if decimated is not None and decimated.faces.size > 0:
                        tm = decimated
            except Exception as e:
                try:
                    from modules.logger import log as app_log
                    app_log("Decimation failed: " + str(e))
                except Exception:
                    pass

    # Smoothing
    if smooth_enabled:
        if smooth_mode == "bilateral":
            try:
                v_smooth = _bilateral_smooth(
                    np.asarray(tm.vertices, dtype=np.float64),
                    np.asarray(tm.faces,    dtype=np.int64),
                    iterations=smooth_iters,
                    sigma_n=float(cfg.get("smooth_sigma_n", 0.45)),
                    lam=smooth_lambda,
                )
                tm = trimesh.Trimesh(v_smooth, tm.faces, process=False)
            except Exception:
                # Fallback to Laplacian on failure
                if filter_laplacian is not None:
                    try:
                        tm = filter_laplacian(tm, lamb=smooth_lambda,
                                              iterations=smooth_iters)
                    except Exception:
                        pass
        else:
            if filter_laplacian is not None:
                try:
                    tm = filter_laplacian(tm, lamb=smooth_lambda,
                                          iterations=smooth_iters)
                except Exception:
                    pass

    try:
        return SimpleMesh(
            vertices=np.asarray(tm.vertices, dtype=np.float32),
            faces=np.asarray(tm.faces,    dtype=np.int32),
        )
    except Exception:
        return mesh
