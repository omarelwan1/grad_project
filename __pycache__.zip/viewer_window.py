
import tkinter as tk
from tkinter import ttk
import numpy as np

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk


class MeshViewerWindow(tk.Toplevel):
    # Interactive 3D viewer window (Matplotlib)
    # Rotate: left mouse drag
    # Zoom: mouse wheel / toolbar zoom
    def __init__(self, master, mesh, landmarks=None, title="Mesh Viewer"):
        super().__init__(master)
        self.title(title)
        self.geometry("900x700")
        self.minsize(800, 600)
        self.configure(background="#10102a")

        # Dark theme styling
        style = ttk.Style(self)
        style.configure("Dark.TFrame", background="#10102a")
        style.configure("Dark.TLabel", background="#10102a", foreground="white")

        root = ttk.Frame(self, style="Dark.TFrame", padding=6)
        root.pack(fill=tk.BOTH, expand=True)

        fig = Figure(figsize=(6, 5), dpi=100, facecolor="#10102a")
        ax = fig.add_subplot(111, projection="3d", facecolor="#10102a")
        ax.set_title("Rotate with mouse drag", color="white")
        ax.set_axis_off()

        v = getattr(mesh, "vertices", np.zeros((0, 3), dtype=np.float32))
        f = getattr(mesh, "faces", np.zeros((0, 3), dtype=np.int32))

        if v.size and f.size:
            # Color map based on depth (Z axis) for premium clinical 3D visualization
            z_colors = v[:, 2]
            ax.plot_trisurf(
                v[:, 0], v[:, 1], v[:, 2],
                triangles=f,
                cmap="magma",
                array=z_colors,
                linewidth=0.0,
                antialiased=True,
                shade=True,
                alpha=0.9
            )
            
            # Plot detected anatomical landmarks
            if landmarks:
                colors_map = {
                    "Head Center": "#ff00ff",      # Neon Magenta
                    "Nose Tip": "#ffaa00",         # Bright Orange
                    "Nose Tip (Est)": "#ffaa00",
                    "Forehead": "#00ffff",         # Neon Cyan
                    "Chin": "#00ff00"              # Neon Green
                }
                markers_map = {
                    "Head Center": "o",
                    "Nose Tip": "*",
                    "Nose Tip (Est)": "*",
                    "Forehead": "^",
                    "Chin": "v"
                }
                for name, pos in landmarks.items():
                    lx, ly, lz = pos
                    color = colors_map.get(name, "#ff3333")
                    marker = markers_map.get(name, "x")
                    
                    # Draw neon highlight marker
                    ax.scatter(lx, ly, lz, color=color, s=160, depthshade=False,
                               marker=marker, edgecolor="white", linewidth=1.5, label=name)
                    # Add label text slightly elevated above the point
                    ax.text(lx, ly, lz + 2.0, name, color="white", fontsize=9, fontweight="bold")
                
                # Add legend
                leg = ax.legend(loc="upper left", facecolor="#1a1a3a", edgecolor="#3a3a6a")
                for text in leg.get_texts():
                    text.set_color("white")

            ax.view_init(elev=30, azim=-60)
            mins = v.min(axis=0); maxs = v.max(axis=0)
            centers = (mins + maxs) / 2.0
            span = float(np.max(maxs - mins) + 1e-6)
            ax.set_xlim(centers[0] - span/2, centers[0] + span/2)
            ax.set_ylim(centers[1] - span/2, centers[1] + span/2)
            ax.set_zlim(centers[2] - span/2, centers[2] + span/2)
            ax.set_box_aspect((1, 1, 0.5))  # Flatten Z axis slightly
        else:
            ax.text2D(0.5, 0.5, "EMPTY MESH", transform=ax.transAxes, ha="center", va="center", color="white")

        canvas = FigureCanvasTkAgg(fig, master=root)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        toolbar = NavigationToolbar2Tk(canvas, root, pack_toolbar=False)
        toolbar.update()
        toolbar.pack(fill=tk.X)

        hint = ttk.Label(root, style="Dark.TLabel", text="Tip: drag to rotate. Use toolbar for zoom/pan/home.", anchor="w")
        hint.pack(fill=tk.X, pady=(6, 0))
