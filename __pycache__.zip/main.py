
import argparse
import json
import traceback
from pathlib import Path
import numpy as np
from PIL import Image

from modules.utils import ensure_dir, list_images, save_image
from pipeline_runner import run_pipeline_on_array, save_mesh_ply

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_dir", required=True)
    ap.add_argument("--output_dir", default="outputs")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    in_dir = Path(args.input_dir)
    out_root = Path(args.output_dir)
    ensure_dir(out_root)

    images = list_images(in_dir)
    if args.limit and args.limit > 0:
        images = images[: args.limit]

    for p in images:
        out_dir = out_root / p.stem
        ensure_dir(out_dir)
        try:
            arr = np.array(Image.open(p).convert("L"), dtype=np.uint8)
            out = run_pipeline_on_array(arr, cfg)

            save_image(out_dir / "01_input.png", out.input_u8)
            save_image(out_dir / "02_preprocessed.png", out.pre_u8)
            save_image(out_dir / "03_mask.png", out.mask_u8)
            if out.edges_u8 is not None:
                save_image(out_dir / "04_edges.png", out.edges_u8)
            save_image(out_dir / "05_pseudovol_slices.png", out.pseudovol_preview_u8)

            save_mesh_ply(out.mesh, out_dir / "mesh.ply")
            with open(out_dir / "metrics.json", "w", encoding="utf-8") as mf:
                json.dump({"image": p.name, **out.metrics}, mf, indent=2)

            print(f"[OK] {p.name} -> {out_dir}")
        except Exception as e:
            print(f"[FAIL] {p.name}: {e}")
            traceback.print_exc()

if __name__ == "__main__":
    main()
