import json
import threading
import traceback
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import numpy as np
from PIL import Image, ImageTk

from pipeline_runner import run_pipeline_on_array, save_mesh_ply
from render_preview import mesh_to_pil
from modules.utils import ensure_dir, save_image
from modules.logger import log
from viewer_window import MeshViewerWindow
from modules.ai_reporting import generate_report
from modules.ai_visualization import generate_ai_scan


def load_cfg():
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ultrasound 2D → Pseudo‑3D → Mesh (Desktop)")
        self.geometry("1280x780")
        self.minsize(1150, 650)

        self.cfg = load_cfg()
        self.current_img_path = None
        self.current_img_arr = None
        self.current_mesh = None
        self.last_out_dir = None
        self.current_metrics = None

        # Gemini Reporting Variables
        gr = self.cfg.get("gemini_reporting", {})
        self.api_key_var = tk.StringVar(value=gr.get("api_key", ""))
        self.patient_id_var = tk.StringVar(value=gr.get("patient_id", ""))
        self.gestational_age_var = tk.StringVar(value=gr.get("gestational_age", ""))
        self.model_var = tk.StringVar(value=gr.get("model", "gemini-2.0-flash"))
        self.report_generated_path = None
        self.current_landmarks = None
        self.ai_synthesis_img = None

        # Make sure exceptions in Tk callbacks are visible
        self.report_callback_exception = self._on_tk_exception

        self._build_ui()
        log("App started")

    def _on_tk_exception(self, exc, val, tb):
        msg = "".join(traceback.format_exception(exc, val, tb))
        log("Tk exception:\n" + msg)
        messagebox.showerror("UI error", msg)

    def _build_ui(self):
        top = ttk.Frame(self, padding=8)
        top.pack(side=tk.TOP, fill=tk.X)

        self.path_var = tk.StringVar(value="No image loaded")
        ttk.Label(top, text="Image:").pack(side=tk.LEFT)
        ttk.Label(top, textvariable=self.path_var, width=92).pack(side=tk.LEFT, padx=(6, 10))

        ttk.Button(top, text="Load Image", command=self.load_image).pack(side=tk.LEFT, padx=6)

        self.run_btn = ttk.Button(top, text="Run Pipeline", command=self.run_pipeline)
        self.run_btn.pack(side=tk.LEFT, padx=6)

        self.viewer_btn = ttk.Button(top, text="Open 3D Viewer", command=self.open_viewer, state=tk.DISABLED)
        self.viewer_btn.pack(side=tk.LEFT, padx=6)

        self.save_btn = ttk.Button(top, text="Save Mesh (.ply)", command=self.save_mesh_manual, state=tk.DISABLED)
        self.save_btn.pack(side=tk.LEFT, padx=6)

        self.open_out_btn = ttk.Button(top, text="Open Output Folder", command=self.open_output_folder, state=tk.DISABLED)
        self.open_out_btn.pack(side=tk.LEFT, padx=6)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill=tk.BOTH, expand=True)

        self.tab_stages = ttk.Frame(self.nb, padding=10)
        self.tab_mesh = ttk.Frame(self.nb, padding=10)
        self.tab_ai = ttk.Frame(self.nb, padding=10)
        self.tab_synthesis = ttk.Frame(self.nb, padding=10)
        
        self.nb.add(self.tab_stages, text="Stages")
        self.nb.add(self.tab_mesh, text="Mesh + Metrics")
        self.nb.add(self.tab_ai, text="AI Clinical Insights")
        self.nb.add(self.tab_synthesis, text="AI 3D Synthesis")

        self.stage_labels = {}
        grid = ttk.Frame(self.tab_stages)
        grid.pack(fill=tk.BOTH, expand=True)

        titles = [
            ("01 Input", "input"),
            ("02 Preprocessed", "pre"),
            ("03 Mask", "mask"),
            ("04 Edges (optional)", "edges"),
            ("05 Pseudo‑volume slices", "pv"),
            ("", "blank"),
        ]
        for i, (title, key) in enumerate(titles):
            r, c = divmod(i, 3)
            cell = ttk.Frame(grid, padding=6, relief="groove")
            cell.grid(row=r, column=c, sticky="nsew", padx=6, pady=6)
            grid.grid_rowconfigure(r, weight=1)
            grid.grid_columnconfigure(c, weight=1)

            ttk.Label(cell, text=title).pack(anchor="w")
            lbl = ttk.Label(cell)
            lbl.pack(fill=tk.BOTH, expand=True)
            self.stage_labels[key] = lbl

        mesh_top = ttk.Frame(self.tab_mesh)
        mesh_top.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(mesh_top)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        right = ttk.Frame(mesh_top)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        ttk.Label(left, text="Mesh preview").pack(anchor="w")
        self.mesh_lbl = ttk.Label(left)
        self.mesh_lbl.pack(fill=tk.BOTH, expand=True)

        ttk.Label(right, text="Metrics / Stats").pack(anchor="w")
        self.metrics_txt = tk.Text(right, height=16, wrap="word")
        self.metrics_txt.pack(fill=tk.BOTH, expand=True)
        self.metrics_txt.insert("1.0", "Run the pipeline to see metrics.")
        self.metrics_txt.config(state=tk.DISABLED)

        # AI Quick Action Panel in Mesh Tab
        ai_quick_frame = ttk.LabelFrame(right, text="AI Clinical Reporting Quick Link", padding=8)
        ai_quick_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Label(ai_quick_frame, text="Generate volumetric reports with anatomical AI explanations.").pack(anchor="w", pady=(0, 4))
        self.quick_gen_btn = ttk.Button(
            ai_quick_frame,
            text="🚀 Generate AI Clinical Report",
            command=self.generate_clinical_report,
            state=tk.DISABLED
        )
        self.quick_gen_btn.pack(fill=tk.X, ipady=4)

        # Build the dedicated AI insights tab
        self._build_ai_tab()
        self._build_synthesis_tab()

        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(self, textvariable=self.status_var, relief="sunken", anchor="w").pack(side=tk.BOTTOM, fill=tk.X)

    def _set_status(self, s: str):
        self.status_var.set(s)
        self.update_idletasks()

    def load_image(self):
        path = filedialog.askopenfilename(
            title="Select ultrasound image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"), ("All files", "*.*")]
        )
        if not path:
            return
        self.current_img_path = path
        self.path_var.set(path)

        try:
            img = Image.open(path).convert("L")
            self.current_img_arr = np.array(img, dtype=np.uint8)
            log(f"Loaded image: {path} shape={self.current_img_arr.shape}")
        except Exception as e:
            log("Load error: " + str(e))
            messagebox.showerror("Load error", f"Could not load image:\n{e}")
            self.current_img_arr = None
            return

        self._show_pil_in_label(self.stage_labels["input"], Image.fromarray(self.current_img_arr), max_size=(380, 275))
        self._clear_outputs()

    def _clear_outputs(self):
        for k in ["pre", "mask", "edges", "pv", "blank"]:
            self.stage_labels[k].configure(image="")
            self.stage_labels[k].image = None
        self.mesh_lbl.configure(image="")
        self.mesh_lbl.image = None

        self.metrics_txt.config(state=tk.NORMAL)
        self.metrics_txt.delete("1.0", tk.END)
        self.metrics_txt.insert("1.0", "Run the pipeline to see metrics.")
        self.metrics_txt.config(state=tk.DISABLED)

        self.save_btn.config(state=tk.DISABLED)
        self.viewer_btn.config(state=tk.DISABLED)
        self.open_out_btn.config(state=tk.DISABLED)
        self.gen_report_btn.config(state=tk.DISABLED)
        self.view_report_btn.config(state=tk.DISABLED)
        self.quick_gen_btn.config(state=tk.DISABLED)

        self.current_mesh = None
        self.last_out_dir = None
        self.current_metrics = None
        self.report_generated_path = None
        self.current_landmarks = None
        self.ai_synthesis_img = None
        self.ai_status_lbl.config(text="Status: Waiting for 3D pipeline...", foreground="orange")
        
        # Synthesis Tab controls
        self.synth_btn.config(state=tk.DISABLED)
        self.save_synth_btn.config(state=tk.DISABLED)
        self.synth_lbl.configure(image="")
        self.synth_lbl.image = None
        self.synth_status_lbl.config(text="Status: Waiting for 3D pipeline...", foreground="orange")

    def run_pipeline(self):
        if self.current_img_arr is None:
            messagebox.showwarning("No image", "Please load an image first.")
            return

        self.run_btn.config(state=tk.DISABLED)
        self.save_btn.config(state=tk.DISABLED)
        self.viewer_btn.config(state=tk.DISABLED)
        self.open_out_btn.config(state=tk.DISABLED)
        self._set_status("Running pipeline... (check auto_outputs/app.log if it seems stuck)")
        log("Pipeline started")

        def worker():
            try:
                out = run_pipeline_on_array(self.current_img_arr, self.cfg)
                out_dir = self._auto_save(out)
                self.after(0, lambda: self._safe_apply_outputs(out, out_dir))
            except Exception:
                msg = traceback.format_exc()
                log("Pipeline error:\n" + msg)
                self.after(0, lambda: messagebox.showerror("Pipeline error", msg))
                self.after(0, lambda: self._set_status("Error. See auto_outputs/app.log"))
            finally:
                self.after(0, lambda: self.run_btn.config(state=tk.NORMAL))

        threading.Thread(target=worker, daemon=True).start()

    def _safe_apply_outputs(self, out, out_dir: Path):
        try:
            self._apply_outputs(out, out_dir)
            self._set_status("Done (auto-saved).")
        except Exception:
            msg = traceback.format_exc()
            log("UI apply error:\n" + msg)
            messagebox.showerror("UI apply error", msg)
            self._set_status("UI error. See auto_outputs/app.log")

    def _auto_save(self, out):
        stem = "image"
        if self.current_img_path:
            stem = Path(self.current_img_path).stem

        candidates = [
            Path.cwd() / "auto_outputs" / stem,
            Path.home() / "ultra_mesh_outputs" / stem,
        ]

        last_err = None
        out_dir = None
        for cand in candidates:
            try:
                ensure_dir(cand)
                out_dir = cand
                break
            except Exception as e:
                last_err = e

        if out_dir is None:
            raise RuntimeError(f"Could not create output directory. Last error: {last_err}")

        save_image(out_dir / "01_input.png", out.input_u8)
        save_image(out_dir / "02_preprocessed.png", out.pre_u8)
        save_image(out_dir / "03_mask.png", out.mask_u8)
        if out.edges_u8 is not None:
            save_image(out_dir / "04_edges.png", out.edges_u8)
        save_image(out_dir / "05_pseudovol_slices.png", out.pseudovol_preview_u8)

        save_mesh_ply(out.mesh, out_dir / "mesh.ply")
        with open(out_dir / "metrics.json", "w", encoding="utf-8") as f:
            json.dump(out.metrics, f, indent=2)

        # Save static mesh rendering for embedding in HTML report
        try:
            mesh_preview_img = mesh_to_pil(out.mesh)
            mesh_preview_img.save(out_dir / "mesh_preview.png")
            log("Saved static mesh rendering for HTML report")
        except Exception as e:
            log(f"Failed to save static mesh rendering: {e}")

        log(f"Auto-saved outputs to: {out_dir}")
        return out_dir

    def _apply_outputs(self, out, out_dir: Path):
        self.last_out_dir = out_dir
        self.open_out_btn.config(state=tk.NORMAL)

        self._show_u8(self.stage_labels["pre"], out.pre_u8)
        self._show_u8(self.stage_labels["mask"], out.mask_u8)
        if out.edges_u8 is not None:
            self._show_u8(self.stage_labels["edges"], out.edges_u8)
        else:
            self.stage_labels["edges"].configure(text="Edges disabled")
        self._show_u8(self.stage_labels["pv"], out.pseudovol_preview_u8, max_size=(380, 275))

        self.current_mesh = out.mesh
        self.current_metrics = out.metrics
        self.current_landmarks = getattr(out, "landmarks", None)
        
        mesh_img = mesh_to_pil(out.mesh)
        self._show_pil_in_label(self.mesh_lbl, mesh_img, max_size=(560, 560))

        import pprint
        self.metrics_txt.config(state=tk.NORMAL)
        self.metrics_txt.delete("1.0", tk.END)
        self.metrics_txt.insert("1.0", pprint.pformat(out.metrics, width=95))
        self.metrics_txt.config(state=tk.DISABLED)

        self.save_btn.config(state=tk.NORMAL)
        self.viewer_btn.config(state=tk.NORMAL)
        self.gen_report_btn.config(state=tk.NORMAL)
        self.quick_gen_btn.config(state=tk.NORMAL)
        self.ai_status_lbl.config(text="Status: Pipeline complete. Ready to generate report.", foreground="green")

        # Enable AI synthesis tab controls
        self.synth_btn.config(state=tk.NORMAL)
        self.synth_status_lbl.config(text="Status: Pipeline complete. Ready to synthesize AI scan.", foreground="green")

    def open_viewer(self):
        if self.current_mesh is None:
            messagebox.showwarning("No mesh", "Run the pipeline first to generate a mesh.")
            return
        MeshViewerWindow(self, self.current_mesh, landmarks=self.current_landmarks, title="Mesh Viewer (interactive)")

    def save_mesh_manual(self):
        if self.current_mesh is None:
            messagebox.showwarning("No mesh", "Run the pipeline first to generate a mesh.")
            return
        out_path = filedialog.asksaveasfilename(
            title="Save mesh as",
            defaultextension=".ply",
            filetypes=[("PLY mesh", "*.ply")]
        )
        if not out_path:
            return
        try:
            save_mesh_ply(self.current_mesh, Path(out_path))
            messagebox.showinfo("Saved", f"Mesh saved:\n{out_path}")
        except Exception as e:
            log("Save error: " + str(e))
            messagebox.showerror("Save error", str(e))

    def open_output_folder(self):
        if not self.last_out_dir:
            return
        try:
            import os, sys, subprocess
            p = str(self.last_out_dir.resolve())
            if sys.platform.startswith("win"):
                os.startfile(p)  # noqa
            elif sys.platform == "darwin":
                subprocess.run(["open", p], check=False)
            else:
                subprocess.run(["xdg-open", p], check=False)
        except Exception as e:
            log("Open folder error: " + str(e))
            messagebox.showerror("Open folder error", str(e))

    def _show_u8(self, label: ttk.Label, arr_u8: np.ndarray, max_size=(380, 275)):
        pil = Image.fromarray(arr_u8)
        self._show_pil_in_label(label, pil, max_size=max_size)

    def _show_pil_in_label(self, label: ttk.Label, pil: Image.Image, max_size=(380, 275)):
        im = pil.copy()
        im.thumbnail(max_size)
        tk_img = ImageTk.PhotoImage(im)
        label.configure(image=tk_img)
        label.image = tk_img

    def _build_ai_tab(self):
        # AI Insights Tab Layout
        ai_left = ttk.Frame(self.tab_ai, padding=10)
        ai_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        ai_right = ttk.Frame(self.tab_ai, padding=10, width=380)
        ai_right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=False)

        # Left Column: Configuration & Notes
        # Frame 1: API Configuration
        api_frame = ttk.LabelFrame(ai_left, text="Gemini API Configuration", padding=10)
        api_frame.pack(fill=tk.X, pady=(0, 15))

        ttk.Label(api_frame, text="Gemini API Key:").grid(row=0, column=0, sticky="w", pady=4)
        api_key_entry = ttk.Entry(api_frame, textvariable=self.api_key_var, show="*", width=45)
        api_key_entry.grid(row=0, column=1, sticky="ew", padx=10, pady=4)
        
        ttk.Label(api_frame, text="Gemini Model:").grid(row=1, column=0, sticky="w", pady=4)
        model_combo = ttk.Combobox(
            api_frame, 
            textvariable=self.model_var, 
            values=["gemini-2.0-flash", "gemini-2.5-flash", "gemini-1.5-flash"],
            state="readonly", 
            width=25
        )
        model_combo.grid(row=1, column=1, sticky="w", padx=10, pady=4)
        api_frame.columnconfigure(1, weight=1)

        # Frame 2: Patient Metadata
        meta_frame = ttk.LabelFrame(ai_left, text="Patient & Clinical Metadata", padding=10)
        meta_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(meta_frame, text="Patient Identifier / Ref:").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(meta_frame, textvariable=self.patient_id_var, width=35).grid(row=0, column=1, sticky="w", padx=10, pady=4)

        ttk.Label(meta_frame, text="Gestational Age / Focus:").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(meta_frame, textvariable=self.gestational_age_var, width=35).grid(row=1, column=1, sticky="w", padx=10, pady=4)

        ttk.Label(meta_frame, text="Clinical Notes / Observations:").grid(row=2, column=0, sticky="nw", pady=(8, 4))
        
        # Clinical Notes Text Box
        self.notes_txt_area = tk.Text(meta_frame, height=12, wrap="word", width=45)
        self.notes_txt_area.grid(row=2, column=1, sticky="nsew", padx=10, pady=(8, 4))
        self.notes_txt_area.insert("1.0", self.cfg.get("gemini_reporting", {}).get("notes", ""))
        
        meta_frame.rowconfigure(2, weight=1)
        meta_frame.columnconfigure(1, weight=1)

        # Right Column: Report Control & Operations
        op_frame = ttk.LabelFrame(ai_right, text="Report Control Center", padding=15)
        op_frame.pack(fill=tk.BOTH, expand=True)

        info_lbl = ttk.Label(
            op_frame, 
            text="Generate a publication-grade, interactive HTML clinical report containing 3D metrics, medical image sequences, and AI insights using Gemini.",
            wraplength=330,
            justify=tk.LEFT
        )
        info_lbl.pack(anchor="w", pady=(0, 20))

        self.ai_status_lbl = ttk.Label(
            op_frame, 
            text="Status: Waiting for 3D pipeline...",
            foreground="orange",
            font=("TkDefaultFont", 10, "bold")
        )
        self.ai_status_lbl.pack(anchor="w", pady=(0, 25))

        self.gen_report_btn = ttk.Button(
            op_frame, 
            text="🚀 Generate Clinical AI Report", 
            command=self.generate_clinical_report,
            state=tk.DISABLED
        )
        self.gen_report_btn.pack(fill=tk.X, ipady=8, pady=5)

        self.view_report_btn = ttk.Button(
            op_frame, 
            text="🌐 Open Report in Browser", 
            command=self.open_generated_report,
            state=tk.DISABLED
        )
        self.view_report_btn.pack(fill=tk.X, ipady=8, pady=5)

    def generate_clinical_report(self):
        api_key = self.api_key_var.get().strip()
        if not api_key:
            messagebox.showwarning("API Key Required", "Please enter a valid Gemini API Key in the 'AI Clinical Insights' tab.")
            self.nb.select(self.tab_ai)
            return

        if not self.last_out_dir or not self.current_metrics:
            messagebox.showwarning("No Data", "Run the 3D pipeline on an image first.")
            return

        # Disable buttons while generating
        self.gen_report_btn.config(state=tk.DISABLED)
        self.quick_gen_btn.config(state=tk.DISABLED)
        self.view_report_btn.config(state=tk.DISABLED)
        self.ai_status_lbl.config(text="Status: Generating clinical report via Gemini...", foreground="blue")
        self._set_status("Calling Gemini API in background...")

        patient_id = self.patient_id_var.get().strip()
        gestational_age = self.gestational_age_var.get().strip()
        notes = self.notes_txt_area.get("1.0", tk.END).strip()

        # Proactively persist settings so they are retained for next launch
        try:
            self.cfg["gemini_reporting"] = {
                "enabled": True,
                "api_key": api_key,
                "model": self.model_var.get(),
                "patient_id": patient_id,
                "gestational_age": gestational_age,
                "notes": notes
            }
            with open("config.json", "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, indent=2)
            log("Saved updated Gemini config settings to config.json")
        except Exception as e:
            log(f"Failed to persist configuration settings: {e}")

        # Run model call in secondary background thread to avoid freezing GUI main loop
        def worker():
            try:
                report_path = generate_report(
                    api_key=api_key,
                    model_name=self.model_var.get(),
                    metrics=self.current_metrics,
                    out_dir=self.last_out_dir,
                    patient_id=patient_id,
                    gestational_age=gestational_age,
                    clinical_notes=notes
                )
                self.report_generated_path = report_path
                self.after(0, self._on_report_success)
            except Exception as e:
                msg = traceback.format_exc()
                log(f"Report generation error:\n{msg}")
                self.after(0, lambda: messagebox.showerror("AI Reporter Error", f"Report failed:\n{e}"))
                self.after(0, self._on_report_failure)

        threading.Thread(target=worker, daemon=True).start()

    def _on_report_success(self):
        self.gen_report_btn.config(state=tk.NORMAL)
        self.quick_gen_btn.config(state=tk.NORMAL)
        self.view_report_btn.config(state=tk.NORMAL)
        self.ai_status_lbl.config(text="Status: Report generated successfully!", foreground="green")
        self._set_status("Clinical report ready.")

        # Ask operator if they want to view the HTML file immediately
        ans = messagebox.askyesno(
            "Report Ready", 
            "The publication-grade HTML clinical report has been compiled successfully!\n\nWould you like to open it in your default web browser now?"
        )
        if ans:
            self.open_generated_report()

    def _on_report_failure(self):
        self.gen_report_btn.config(state=tk.NORMAL)
        self.quick_gen_btn.config(state=tk.NORMAL)
        self.ai_status_lbl.config(text="Status: Report generation failed.", foreground="red")
        self._set_status("Report generation failed. See auto_outputs/app.log")

    def open_generated_report(self):
        if not self.report_generated_path or not self.report_generated_path.exists():
            messagebox.showerror("File Error", "Report HTML file not found.")
            return
        try:
            webbrowser.open(self.report_generated_path.as_uri())
            log(f"Opened report in default browser: {self.report_generated_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open report in browser:\n{e}")

    def _build_synthesis_tab(self):
        # AI Fetal Scan 3D Synthesis Tab Layout
        synth_left = ttk.Frame(self.tab_synthesis, padding=10, width=320)
        synth_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=False)

        synth_right = ttk.Frame(self.tab_synthesis, padding=10)
        synth_right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Left Column: Controls & Explanations
        ctrl_frame = ttk.LabelFrame(synth_left, text="AI Visualization Controls", padding=15)
        ctrl_frame.pack(fill=tk.BOTH, expand=True)

        info_lbl = ttk.Label(
            ctrl_frame,
            text="Enhances the raw 2D ultrasound using localized clinical contrast boosting, and overlays detected anatomical landmarks (Forehead, Nose Tip, Chin, Head Center) with high-visibility neon markers and pointers for publication-grade diagnostic visibility.",
            wraplength=280,
            justify=tk.LEFT
        )
        info_lbl.pack(anchor="w", pady=(0, 20))

        self.synth_status_lbl = ttk.Label(
            ctrl_frame,
            text="Status: Waiting for 3D pipeline...",
            foreground="orange",
            font=("TkDefaultFont", 10, "bold")
        )
        self.synth_status_lbl.pack(anchor="w", pady=(0, 25))

        self.synth_btn = ttk.Button(
            ctrl_frame,
            text="🚀 Highlight Fetal Features",
            command=self.synthesize_ai_scan,
            state=tk.DISABLED
        )
        self.synth_btn.pack(fill=tk.X, ipady=8, pady=5)

        self.save_synth_btn = ttk.Button(
            ctrl_frame,
            text="💾 Save Annotated Scan",
            command=self.save_ai_scan_manual,
            state=tk.DISABLED
        )
        self.save_synth_btn.pack(fill=tk.X, ipady=8, pady=5)

        # Right Column: Side-by-Side Visuals
        display_frame = ttk.LabelFrame(synth_right, text="Anatomical Highlight Panel", padding=10)
        display_frame.pack(fill=tk.BOTH, expand=True)

        # 1. Structural Template (Left)
        template_cell = ttk.Frame(display_frame, padding=6, relief="groove")
        template_cell.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=6)
        ttk.Label(template_cell, text="Original 2D Ultrasound Scan", font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(0, 5))
        
        self.synth_ref_lbl = ttk.Label(template_cell, text="No image loaded", anchor="center")
        self.synth_ref_lbl.pack(fill=tk.BOTH, expand=True)

        # 2. Generative Scan (Right)
        gen_cell = ttk.Frame(display_frame, padding=6, relief="groove")
        gen_cell.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=6)
        ttk.Label(gen_cell, text="Enhanced & Highlighted Features Map", font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(0, 5))

        self.synth_lbl = ttk.Label(gen_cell, text="Click Highlight to generate map", anchor="center")
        self.synth_lbl.pack(fill=tk.BOTH, expand=True)

    def synthesize_ai_scan(self):
        if not self.current_landmarks or not self.current_img_path:
            messagebox.showwarning("No Data", "Please run the 3D reconstruction pipeline on an ultrasound first.")
            return

        self.synth_btn.config(state=tk.DISABLED)
        self.save_synth_btn.config(state=tk.DISABLED)
        self.synth_status_lbl.config(text="Status: Enhancing features...", foreground="blue")
        self._set_status("Running anatomical overlay and contrast boost...")

        # Display original 2D ultrasound on the left side of comparison tab
        orig_img = Image.open(self.current_img_path)
        self._show_pil_in_label(self.synth_ref_lbl, orig_img, max_size=(440, 440))

        # Run synthesis in a background thread to prevent UI freezing
        def worker():
            try:
                img = generate_ai_scan(self.current_landmarks, Path(self.current_img_path))
                self.after(0, lambda: self._on_synthesis_success(img))
            except Exception as e:
                err_str = str(e)
                self.after(0, lambda: self._on_synthesis_failure(err_str))

        threading.Thread(target=worker, daemon=True).start()

    def _on_synthesis_success(self, img: Image.Image):
        self.ai_synthesis_img = img
        self.synth_btn.config(state=tk.NORMAL)
        self.save_synth_btn.config(state=tk.NORMAL)
        self.synth_status_lbl.config(text="Status: Synthesis completed successfully!", foreground="green")
        self._set_status("AI Synthesis complete.")

        # Show generated image
        self._show_pil_in_label(self.synth_lbl, img, max_size=(440, 440))

        # Auto-save generated image to last output folder
        if self.last_out_dir:
            try:
                img.save(self.last_out_dir / "ai_volumetric_synthesis.png")
                log(f"Auto-saved AI synthesis scan to {self.last_out_dir}")
            except Exception as e:
                log(f"Failed to auto-save AI synthesis scan: {e}")

    def _on_synthesis_failure(self, err_msg: str):
        self.synth_btn.config(state=tk.NORMAL)
        self.synth_status_lbl.config(text="Status: Synthesis failed.", foreground="red")
        self._set_status("AI Synthesis failed. See auto_outputs/app.log")
        messagebox.showerror("AI Synthesis Error", f"Failed to synthesize AI scan:\n{err_msg}")

    def save_ai_scan_manual(self):
        if self.ai_synthesis_img is None:
            messagebox.showwarning("No image", "Synthesize a 3D AI scan first.")
            return
        out_path = filedialog.asksaveasfilename(
            title="Save AI Scan As",
            defaultextension=".png",
            filetypes=[("PNG Image", "*.png"), ("JPEG Image", "*.jpg")]
        )
        if not out_path:
            return
        try:
            self.ai_synthesis_img.save(out_path)
            messagebox.showinfo("Success", f"AI volumetric scan saved to:\n{out_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save AI scan:\n{e}")


if __name__ == "__main__":
    app = App()
    app.mainloop()
