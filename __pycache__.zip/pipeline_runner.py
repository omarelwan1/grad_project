
from __future__ import annotations
import time
from dataclasses import dataclass
from typing import Dict, Optional
import numpy as np

from modules.utils import to_uint8, resize_keep_aspect_pad
from modules.preprocess import perona_malik_diffusion, normalize01, despeckle
from modules.segment import segment_mask
from modules.edges import extract_edges
from modules.pseudovolume import build_pseudovolume, make_volume_slices_preview
from modules.meshing import extract_mesh_marching_cubes, postprocess_mesh
from modules.metrics import silhouette_iou, mesh_quality_stats

from modules.landmarks import detect_landmarks

@dataclass
class StageOutputs:
    input_u8: np.ndarray
    pre_u8: np.ndarray
    mask_u8: np.ndarray
    edges_u8: Optional[np.ndarray]
    pseudovol_preview_u8: np.ndarray
    mesh: object
    metrics: Dict
    landmarks: Optional[Dict[str, tuple]] = None

def run_pipeline_on_array(img_gray_u8_or_f: np.ndarray, cfg: dict) -> StageOutputs:
    t0 = time.perf_counter()
    img = img_gray_u8_or_f.astype(np.float32)
    if img.max() > 1.5:
        img = img / 255.0
    img = np.clip(img, 0.0, 1.0)

    img0 = resize_keep_aspect_pad(img * 255.0, cfg["target_size"]) / 255.0
    input_u8 = to_uint8(img0)

    img01 = normalize01(img0)
    p = cfg["preprocess"]

    # Step 1: mild despeckle (median + optional bilateral)
    img_ds = despeckle(
        img01,
        median_size=int(p.get("median_size", 3)),
        use_bilateral=bool(p.get("use_bilateral", True)),
        bilateral_sigma_color=float(p.get("bilateral_sigma_color", 0.08)),
        bilateral_sigma_spatial=float(p.get("bilateral_sigma_spatial", 3.0)),
    )

    # Step 2: edge-preserving diffusion (Perona-Malik)
    img_pre = perona_malik_diffusion(
        img_ds,
        niter=int(p.get("perona_malik_iters", 12)),
        kappa=float(p.get("perona_malik_kappa", 0.08)),
        gamma=float(p.get("perona_malik_gamma", 0.15)),
    )
    pre_u8 = to_uint8(img_pre)

    mask = segment_mask(img_pre, cfg["segmentation"])
    mask_u8 = (mask * 255).astype(np.uint8)

    edges_u8 = None
    if cfg["edges"]["enabled"]:
        edges_u8 = (extract_edges(img_pre, cfg["edges"]) * 255).astype(np.uint8)

    vol_cfg = cfg["pseudovolume"]
    volume = build_pseudovolume(img_pre, mask, vol_cfg)
    pseudovol_preview_u8 = to_uint8(make_volume_slices_preview(volume, n_slices=9))

    mesh = extract_mesh_marching_cubes(volume, level=float(vol_cfg["iso_level"]), vol_cfg=vol_cfg)
    mesh = postprocess_mesh(mesh, cfg["meshing"])

    iou = silhouette_iou(mesh, mask)
    q = mesh_quality_stats(mesh)
    t1 = time.perf_counter()

    metrics = {
        "silhouette_iou": float(iou),
        "triangles": int(mesh.faces.shape[0]),
        "vertices": int(mesh.vertices.shape[0]),
        "mesh_quality": q,
        "runtime_seconds": float(t1 - t0),
        "empty_mesh": bool((mesh.faces.size == 0) or (mesh.vertices.size == 0)),
    }

    landmarks = detect_landmarks(mask, volume, img_pre=img_pre)

    return StageOutputs(
        input_u8=input_u8,
        pre_u8=pre_u8,
        mask_u8=mask_u8,
        edges_u8=edges_u8,
        pseudovol_preview_u8=pseudovol_preview_u8,
        mesh=mesh,
        metrics=metrics,
        landmarks=landmarks,
    )

def save_mesh_ply(mesh, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    mesh.export_ply(str(out_path))
