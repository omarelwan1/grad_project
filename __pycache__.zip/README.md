# Ultrasound 2D → Pseudo‑3D → Mesh (Desktop UI v2)

Desktop app (Tkinter). Open `app.py` in PyCharm and press **Run**.

## Install
pip install -r requirements.txt

## Run
python app.py

## Features
- Load an ultrasound image
- Run pipeline and view all stages
- Auto-save results to `auto_outputs/<image_name>/`
  - stage images + `mesh.ply` + `metrics.json`
- Open a separate interactive 3D viewer window to rotate/zoom the mesh
- Save mesh manually to a custom path

## Optional CLI batch run
python main.py --input_dir /path/to/images --output_dir outputs


## If your mask is empty/black
In v3, segmentation defaults to `fetus_heuristic` to avoid the common border-clearing issue on ultrasound wedges.


## Trimesh note
If your installed `trimesh` is very old, v4 uses safe fallbacks so the pipeline still runs. For best results: `pip install -U trimesh`.


## If clicking Run Pipeline does 'nothing'
Open `auto_outputs/app.log` after pressing Run. v5 logs all steps and shows hidden callback errors.


## Preprocessed looks like salt/pepper?
Use v6 (median + bilateral + diffusion). Tweak `config.json` → preprocess:
- `median_size` (3 or 5)
- `bilateral_sigma_color` (0.05–0.12)
- `bilateral_sigma_spatial` (2–5)
- `perona_malik_kappa` (0.05–0.12)

## 3D Viewer shows EMPTY MESH
That means Marching Cubes got no surface. v6 switches pseudo-volume to `filled_thickness` which is more robust for single 2D images.
